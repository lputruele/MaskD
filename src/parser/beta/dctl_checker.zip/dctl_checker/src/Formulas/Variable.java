package Formulas;

public class Variable implements FormulaElement {
	
	private String name;
	
	public Variable(String n){
		name = n;
	}
	

	public void accept(FormulaVisitor visitor){
		 visitor.visit(this);
		 
	 }	
		

    public String toString(){    	
    	return name;
    };

}
