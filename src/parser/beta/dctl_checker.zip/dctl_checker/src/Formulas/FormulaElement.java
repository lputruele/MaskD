package Formulas;

public interface FormulaElement {
	 	
	 public void accept(FormulaVisitor visitor);
     public String toString();
}
