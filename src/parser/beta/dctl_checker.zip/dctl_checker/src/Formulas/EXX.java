package Formulas;

public class EXX extends Exists {

	public EXX(String op,FormulaElement e1, FormulaElement e2){
        super(op,e1,e2);		
	}
	

	public void accept(FormulaVisitor v){
	     v.visit(this);			
	}
	
}
