package Formulas;

import net.sf.javabdd.*;
import ModelChecker.BDDModel;


public class SatVisitor implements FormulaVisitor {

	private BDD sat;
	private BDDModel model;
	

	/**
	 * Pre: The model m should be initialized correctly.
	 * Posc: Initializes a new visitor with the parameters received.
	 */
	public SatVisitor(BDDModel m){
		sat = null;
		model = m;
	}
	
	@Override
	public void visit(Variable v) {
            
		String name = v.toString();
		int id =model.getVarID(name);
		sat = model.getFactory().ithVar(id); //restringo a aquellos estados donde la variable es true.
		System.out.println("prueba compilacion!!!!!");
	}

	/** 
	 * Returns the BDD zero or one, depending if the constant value is True or false, respectively
	 * */
	@Override
	public void visit(Constant c) {
		sat = c.getValue() ? model.getFactory().one() : model.getFactory().zero();
	}

	@Override
	public void visit(Negation n) {
		n.getExpr1().accept(this);
                sat = this.getSat().not();
	}

	
	public void visit(Implication i) {
		i.getExpr1().accept(this);
		BDD sat_np = this.getSat().not();
		i.getExpr2().accept(this);
		sat = sat_np.or(this.getSat());
	}

	@Override
	public void visit(Conjunction c) {
		c.getExpr1().accept(this);
		BDD sat_p = this.getSat();
		c.getExpr2().accept(this);
		sat = sat_p.and(this.getSat());

	}

	@Override
	public void visit(Disjunction d) {
		d.getExpr1().accept(this);
		BDD sat_p = this.getSat();
		d.getExpr2().accept(this);
		sat = sat_p.or(this.getSat());
	}

	@Override
	public void visit(Next n) {
		

	}

	@Override
	public void visit(Until u) {		

	}

	@Override
	public void visit(OXX o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(OXU o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(OUX o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(OUU o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(PXX p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(PXU p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(PUX p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(PUU p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(Recovery r) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(AXX a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(AXU a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(AUX a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(AUU a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(EXX e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(EXU e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(EUX e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void visit(EUU e) {
		// TODO Auto-generated method stub

	}
	
	/** 
	 * Returns the BDD that the represents the set of states of the model that satisfy the current formula.
	 * */
	public BDD getSat(){
		return sat;		
	}
	
	/***
	 * 
	 * @param m
	 * @param f
	 * @return returns the successor set of states reached in a step from the state b.
	 */
	private BDD Post(BDD s){
		BDD trans = model.getTransitions();
		BDD rest = trans.restrict(s);
		// falta renombrar las vbles primadas..... v <- v'
		// pero que se hace cuando tenes por ej [0,-1,-1,1,0,0]
		return 	rest;	
	}
	
	
	/***
	 * 
	 * @param m
	 * @param f
	 * @return returns the successor set of "normal" states reached in a step from the state b.
	 */
	private BDD Post_N(BDD b){
		BDD trans = model.getTransitions();
		return trans.restrict(b).and(model.getNormative());		
	}
	
	/***
	 * 
	 * @param f
	 * @return Compute the set Sat( P (X f) )
	 */
	private void SatPX(FormulaElement f){
		// Sat( P(X f) ) = {s in Normatives / Post_N (s) intersection Sat(f) != Empty}
		// Exists x' / ( )
		f.accept(this);
		BDD sat_f = this.getSat();		
		//sat = model.getNormative().exist((Post_N(model.getNormative()).and(sat_f)));
		sat =(Post_N(model.getNormative()).and(sat_f)).exist(model.getNormative());
	}
	
	
	/***
	 * 
	 * @param f
	 * @return Compute the greatest fixed point of the formula 
	 */
	private void GFP(FormulaElement f){
		f.accept(this);
		sat = this.sat;
		
	}
	
	/***
	 * 
	 * @param f
	 * @return Compute the Least fixed point of the formula 
	 */
	private void LFP(FormulaElement f){
		f.accept(this);
		sat = this.sat;
		
	}

}
