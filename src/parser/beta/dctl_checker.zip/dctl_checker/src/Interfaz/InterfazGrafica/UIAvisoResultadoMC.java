package Interfaz.InterfazGrafica;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class UIAvisoResultadoMC extends javax.swing.JDialog {

    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */    
    public UIAvisoResultadoMC(UIModelo uiModelo, boolean modal) {
        super(uiModelo, modal);
        initComponents();
         this.setLocationRelativeTo(uiModelo);
    }

    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ---MÉTODO QUE INICIALIZA LAS CARACTERÍSTICAS GRÁFICAS DE LA VENTANA---
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new javax.swing.JPanel();
        jPanelBoton = new javax.swing.JPanel();
        jButtonAceptar = new javax.swing.JButton();
        jPanelMensaje = new javax.swing.JPanel();
        jLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(350, 108));

        jPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel.setLayout(new java.awt.BorderLayout());

        jButtonAceptar.setText("Aceptar");
        jButtonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAceptarActionPerformed(evt);
            }
        });
        jPanelBoton.add(jButtonAceptar);

        jPanel.add(jPanelBoton, java.awt.BorderLayout.PAGE_END);

        jPanelMensaje.setLayout(new java.awt.BorderLayout());

        jLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanelMensaje.add(jLabel, java.awt.BorderLayout.CENTER);

        jPanel.add(jPanelMensaje, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
      MÉTODO QUE SE INVOCA AL HACER CLIC EN BOTÓN "ACEPTAR"
    */
    private void jButtonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAceptarActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButtonAceptarActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAceptar;
    private javax.swing.JLabel jLabel;
    private javax.swing.JPanel jPanel;
    private javax.swing.JPanel jPanelBoton;
    private javax.swing.JPanel jPanelMensaje;
    // End of variables declaration//GEN-END:variables

 public  void setResultado(String error){
        jLabel.setText(error);
    }
}

