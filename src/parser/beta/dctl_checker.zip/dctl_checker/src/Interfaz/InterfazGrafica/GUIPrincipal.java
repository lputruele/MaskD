package Interfaz.InterfazGrafica;


import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import Interfaz.Eventos.EventosGUIPrincipal.ActionListenerGUIPrincipal;
import Interfaz.AuxiliarInterfaz.PanelConFondo;
import javax.swing.JFrame;
import javax.swing.JMenuItem;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class GUIPrincipal extends JFrame {

    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public GUIPrincipal() {
        ManipulacionArchivos manipulacionArchivos = new ManipulacionArchivos();
        String separador = System.getProperty("file.separator");
        PanelConFondo panelConFondo = new PanelConFondo(manipulacionArchivos.buscarRuta(separador + "Imagenes"+separador+"ImagenFondo.jpg"));  
        this.setContentPane(panelConFondo);//Agrega panel con fondo a GUIPrincipal
        initComponents();//Inicializa algunas de las características gráficas
                         //de la ventana 
        this.setLocationRelativeTo(null);//Centraliza GUIPrincipal
        ActionListenerGUIPrincipal actionListenerGUIPrincipal = new ActionListenerGUIPrincipal(this);
        jMenuItemAbrirModelo.addActionListener(actionListenerGUIPrincipal);
        jMenuItemNuevoModelo.addActionListener(actionListenerGUIPrincipal);
        System.out.println("probando compilacion GUI");
        

    }
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ---MÉTODO QUE INICIALIZA LAS CARACTERÍSTICAS GRÁFICAS DE LA VENTANA---
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar = new javax.swing.JMenuBar();
        jMenuArchivo = new javax.swing.JMenu();
        jMenuItemNuevoModelo = new javax.swing.JMenuItem();
        jMenuItemAbrirModelo = new javax.swing.JMenuItem();
        jMenuItemSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("dCTL-Checker");

        jMenuArchivo.setText("Archivo");

        jMenuItemNuevoModelo.setText("Nuevo modelo");
        jMenuArchivo.add(jMenuItemNuevoModelo);

        jMenuItemAbrirModelo.setText("Abrir modelo");
        jMenuArchivo.add(jMenuItemAbrirModelo);

        jMenuItemSalir.setText("Salir");
        jMenuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSalirActionPerformed(evt);
            }
        });
        jMenuArchivo.add(jMenuItemSalir);

        jMenuBar.add(jMenuArchivo);

        setJMenuBar(jMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 374, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_jMenuItemSalirActionPerformed

    
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenuArchivo;
    private javax.swing.JMenuBar jMenuBar;
    private javax.swing.JMenuItem jMenuItemAbrirModelo;
    private javax.swing.JMenuItem jMenuItemNuevoModelo;
    private javax.swing.JMenuItem jMenuItemSalir;
    // End of variables declaration//GEN-END:variables

    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    public JMenuItem getMenuItemAbrirModelo(){
        return jMenuItemAbrirModelo;
    }
    
    
    public JMenuItem getMenuItemNuevoModelo(){
        return jMenuItemNuevoModelo;
    }
}
