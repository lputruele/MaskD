package Interfaz.InterfazGrafica;



import Interfaz.AuxiliarInterfaz.ConfiguracionTexto;
import Interfaz.Eventos.EventosUIModelo.ActionListenerUIModelo;
import Interfaz.Eventos.EventosUIModelo.KeyListenerUIModelo;
import Interfaz.Eventos.EventosUIModelo.ListSelectionListenerUIModelo;
import Interfaz.Eventos.EventosUIModelo.WindowListenerUIModelo;
import Interfaz.AuxiliarInterfaz.PanelNumerosEditor;
import java.awt.BorderLayout;
import java.awt.Button;
import java.util.LinkedList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import net.sf.javabdd.BDD;
import Formulas.FormulaElement; 




/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class UIModelo extends javax.swing.JDialog {

    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    
    
    public UIModelo(GUIPrincipal parent, boolean modal) {
        super(parent, modal);//Constructor de JDialog
        initComponents();//Inicializa algunas de las características gráficas
                         //de la ventana 
        this.parent=parent;//Almacena la instancia GUIPrincipal desde donde
                           //se visualiza una instancia de UIModelo

        
        
        inicializacion();//Inicializa otras características gráficas de la
                         //ventana. Se definen las acciones a ejecutarlse
                         //después del evento de pulsar tecla    
        
        esModeloEditado=false;
        propiedadesGuardadas=new LinkedList();
        lista_rutaPropiedad = new LinkedList();
        resultadoAnalisisModelo="";
        resultadoAnalisisPropiedad="";
  
    }

    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public UIModelo(UIModelo parent, boolean modal) {
        super(parent, modal);//Constructor de JDialog
        initComponents();//Inicializa algunas de las características gráficas
                         //de la ventana 
        
        inicializacion();//Inicializa otras características gráficas de la
                         //ventana. Se definen las acciones a ejecutarlse
                         //después del evento de pulsar tecla
 
        esModeloEditado=false;
        propiedadesGuardadas=new LinkedList();
        lista_rutaPropiedad = new LinkedList();
        resultadoAnalisisModelo=new String("");
        resultadoAnalisisPropiedad=new String("");
    }

    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ---MÉTODO QUE INICIALIZA LAS CARACTERÍSTICAS GRÁFICAS DE LA VENTANA---
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenuEditarGuardarPropiedad = new javax.swing.JPopupMenu();
        jMenuItemPopupGuardar = new javax.swing.JMenuItem();
        jMenuItemPopupEditar = new javax.swing.JMenuItem();
        jMenuItemPopupCopiarPropiedad = new javax.swing.JMenuItem();
        jTabbedPane = new javax.swing.JTabbedPane();
        jInternalFrameModelo = new javax.swing.JInternalFrame();
        jPanelAnalizar = new javax.swing.JPanel();
        buttonAnalizarSintaxis = new java.awt.Button();
        jSplitPane = new javax.swing.JSplitPane();
        jMenuBarModelo = new javax.swing.JMenuBar();
        jMenuArchivo = new javax.swing.JMenu();
        jMenuItemNuevo = new javax.swing.JMenuItem();
        jMenuItemAbrir = new javax.swing.JMenuItem();
        jMenuItemGuardarComo = new javax.swing.JMenuItem();
        jMenuItemGuardar = new javax.swing.JMenuItem();
        jMenuEditar = new javax.swing.JMenu();
        jMenuItemCopiar = new javax.swing.JMenuItem();
        jMenuItemPegar = new javax.swing.JMenuItem();
        jMenuItemCortar = new javax.swing.JMenuItem();
        jMenuVer = new javax.swing.JMenu();
        jMenuItemDOT = new javax.swing.JMenuItem();
        jMenuItemBDD = new javax.swing.JMenuItem();
        jMenuVentana = new javax.swing.JMenu();
        jMenuItemMaximizar = new javax.swing.JMenuItem();
        jMenuItemSalir = new javax.swing.JMenuItem();
        jInternalFramePropiedad = new javax.swing.JInternalFrame();
        jPanelListaPropiedades = new javax.swing.JPanel();
        jPanelChequear = new javax.swing.JPanel();
        jButtonChequear = new java.awt.Button();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaPropiedad = new javax.swing.JList();
        jMenuBarPropiedad = new javax.swing.JMenuBar();
        jMenuEditarLista = new javax.swing.JMenu();
        jMenuItemNuevaPropiedad = new javax.swing.JMenuItem();
        jMenuItemAbrirPropiedad = new javax.swing.JMenuItem();
        jMenuItemEliminarPropiedad = new javax.swing.JMenuItem();
        jMenuItemVaciarLista = new javax.swing.JMenuItem();
        jMenuItemEditarPropiedad = new javax.swing.JMenuItem();
        jMenuItemGuardarPropiedad = new javax.swing.JMenuItem();
        jMenuItemCopiarPropiedad = new javax.swing.JMenuItem();

        jMenuItemPopupGuardar.setText("Guardar");
        jPopupMenuEditarGuardarPropiedad.add(jMenuItemPopupGuardar);

        jMenuItemPopupEditar.setText("Editar");
        jPopupMenuEditarGuardarPropiedad.add(jMenuItemPopupEditar);

        jMenuItemPopupCopiarPropiedad.setText("Copiar");
        jPopupMenuEditarGuardarPropiedad.add(jMenuItemPopupCopiarPropiedad);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jTabbedPane.setBackground(java.awt.Color.white);
        jTabbedPane.setOpaque(true);

        jInternalFrameModelo.setBackground(java.awt.Color.white);
        jInternalFrameModelo.setVisible(true);

        jPanelAnalizar.setBackground(java.awt.Color.white);

        buttonAnalizarSintaxis.setActionCommand("Analizar");
        buttonAnalizarSintaxis.setLabel("Analizar");
        jPanelAnalizar.add(buttonAnalizarSintaxis);

        jInternalFrameModelo.getContentPane().add(jPanelAnalizar, java.awt.BorderLayout.PAGE_END);

        jSplitPane.setBackground(java.awt.Color.white);
        jSplitPane.setDividerLocation(250);
        jSplitPane.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        jInternalFrameModelo.getContentPane().add(jSplitPane, java.awt.BorderLayout.CENTER);

        jMenuArchivo.setText("Archivo");

        jMenuItemNuevo.setText("Nuevo");
        jMenuArchivo.add(jMenuItemNuevo);

        jMenuItemAbrir.setText("Abrir");
        jMenuArchivo.add(jMenuItemAbrir);

        jMenuItemGuardarComo.setText("Guardar como");
        jMenuArchivo.add(jMenuItemGuardarComo);

        jMenuItemGuardar.setText("Guardar");
        jMenuArchivo.add(jMenuItemGuardar);

        jMenuBarModelo.add(jMenuArchivo);

        jMenuEditar.setText("Editar");

        jMenuItemCopiar.setText("Copiar");
        jMenuEditar.add(jMenuItemCopiar);

        jMenuItemPegar.setText("Pegar");
        jMenuEditar.add(jMenuItemPegar);

        jMenuItemCortar.setText("Cortar");
        jMenuEditar.add(jMenuItemCortar);

        jMenuBarModelo.add(jMenuEditar);

        jMenuVer.setText("Ver");

        jMenuItemDOT.setText("DOT");
        jMenuVer.add(jMenuItemDOT);

        jMenuItemBDD.setText("BDD");
        jMenuVer.add(jMenuItemBDD);

        jMenuBarModelo.add(jMenuVer);

        jMenuVentana.setText("Ventana");

        jMenuItemMaximizar.setText("Maximizar");
        jMenuVentana.add(jMenuItemMaximizar);

        jMenuItemSalir.setText("Salir");
        jMenuVentana.add(jMenuItemSalir);

        jMenuBarModelo.add(jMenuVentana);

        jInternalFrameModelo.setJMenuBar(jMenuBarModelo);

        jTabbedPane.addTab("Modelo", jInternalFrameModelo);

        jInternalFramePropiedad.setBackground(java.awt.Color.white);
        jInternalFramePropiedad.setTitle("Lista de propiedades");
        jInternalFramePropiedad.setVisible(true);

        jPanelListaPropiedades.setBackground(java.awt.Color.lightGray);
        jPanelListaPropiedades.setPreferredSize(new java.awt.Dimension(400, 400));
        jPanelListaPropiedades.setLayout(new java.awt.BorderLayout());

        jButtonChequear.setActionCommand("Chequear");
        jButtonChequear.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jButtonChequear.setLabel("Chequear");
        jPanelChequear.add(jButtonChequear);

        jPanelListaPropiedades.add(jPanelChequear, java.awt.BorderLayout.PAGE_END);

        listaPropiedad.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listaPropiedad.setComponentPopupMenu(jPopupMenuEditarGuardarPropiedad);
        jScrollPane1.setViewportView(listaPropiedad);

        jPanelListaPropiedades.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jInternalFramePropiedad.getContentPane().add(jPanelListaPropiedades, java.awt.BorderLayout.CENTER);

        jMenuEditarLista.setText("Editar lista");

        jMenuItemNuevaPropiedad.setText("Nueva");
        jMenuEditarLista.add(jMenuItemNuevaPropiedad);

        jMenuItemAbrirPropiedad.setText("Abrir");
        jMenuEditarLista.add(jMenuItemAbrirPropiedad);

        jMenuItemEliminarPropiedad.setText("Eliminar");
        jMenuEditarLista.add(jMenuItemEliminarPropiedad);

        jMenuItemVaciarLista.setText("Vaciar lista");
        jMenuEditarLista.add(jMenuItemVaciarLista);

        jMenuItemEditarPropiedad.setText("Editar");
        jMenuEditarLista.add(jMenuItemEditarPropiedad);

        jMenuItemGuardarPropiedad.setText("Guardar");
        jMenuEditarLista.add(jMenuItemGuardarPropiedad);

        jMenuItemCopiarPropiedad.setText("Copiar");
        jMenuEditarLista.add(jMenuItemCopiarPropiedad);

        jMenuBarPropiedad.add(jMenuEditarLista);

        jInternalFramePropiedad.setJMenuBar(jMenuBarPropiedad);

        jTabbedPane.addTab("Propiedad", jInternalFramePropiedad);

        getContentPane().add(jTabbedPane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    /*
       MÉTODO QUE INICIALIZA CARACTERÍSTICAS GRÁFICAS DE LA VENTANA:
       NÚMERO DE LÍNEAS EN LA SECCIÓN DE ESCRITURA, DISTINTOS FORMATOS DE
       TEXTO, POSICIÓN DEL CURSOR, Y FUNCIONALIDADES QUE SE HABILITAN.
       SE DEFINEN LAS ACCIONES A EJECUTARSE DESPUÉS DEL EVENTO DE PULSAR TECLA
       
    */
    private void inicializacion(){
         this.setLocationRelativeTo(parent);//Centraliza el JDIalog
        
        
        /* - Se crea el contenedor de texto del modelo.
           - Se crea el panel del editor, que contiene al contenedor de texto 
             del modelo, con BorderLayout
           - Se crea el JScrollPane que contiene al panel del editor
           - Se agrega el contenedor de texto de las líneas, al "Row Header" del
             JScrollPane del editor
           - Se configura color de fondo para el contenedor de texto de las 
             líneas
           - Se agrega el JScrollPane del editor, en JSplitPane, en "top"
        */
        contenedorTextoModelo = new JTextPane();
        JPanel jPanelEditor = new JPanel(new BorderLayout());
        jPanelEditor.add(BorderLayout.CENTER, contenedorTextoModelo);
        jScrollPaneEditor = new JScrollPane(jPanelEditor);
        PanelNumerosEditor panelNumeros = new PanelNumerosEditor(contenedorTextoModelo);
        jScrollPaneEditor.setRowHeaderView( panelNumeros );
        jSplitPane.setTopComponent(jScrollPaneEditor);
        
        /* - Se crea el contenedor de texto que muestra resultados, mensajes.
           - Se crea el panel de resultados, que contiene al contenedor de texto 
             de resultados, con BorderLayout
           - Se crea el JScrollPane que contiene al panel de resultados
           - Se agrega el JScrollPane de resultados, en JSplitPane, en "bottom"
        */
        jTextPaneResultadoAnalisis = new JTextPane();
        jPanelResultadoAnalisis = new JPanel( new BorderLayout() );
        jPanelResultadoAnalisis.add( jTextPaneResultadoAnalisis );
        jScrollPaneResultadoAnalisis = new JScrollPane( jPanelResultadoAnalisis );
        jSplitPane.setBottomComponent(jScrollPaneResultadoAnalisis);
        
        ConfiguracionTexto.configurar();

        contenedorTextoModelo.setCharacterAttributes(ConfiguracionTexto.getFormatoClasico(), true);//Se inicializa el contenedor
                                                                           //de texto para el modelo,con uno 
                                                                           //de los formatos definidos
                                                                           //agregarTexto(-1,"1",formatoClasico, jTextPaneLineas);
                                                                           //Se inicializa la ventana abierta
                                                                           //para la escritura de un modelo,
                                                                           //mostrando sólo la línea 1
                                                       
        contenedorTextoModelo.requestFocusInWindow();//Se inicializa la ventana con el cursor posicionado
                                                     //en el contenedor de texto para la escritura del modelo
        
        
        rutaArchivoActual="";//Se almacena cadena vacía para la variable que almacena
                             //la ruta, nombre y extensión del último arhivo abierto
        
        
        /*
           Se deshabilitan las funcionalidades "Ver DOT", "Ver BDD" y "Chequear"
        */
        jMenuItemDOT.setEnabled(false);
        jMenuItemBDD.setEnabled(false);
        jButtonChequear.setEnabled(false);

                
        /*
            Se crea lista de propiedades y se deshabilitan las funcionalidades 
            de las propiedades 'editar', 'eliminar' y 'vaciar'
        */ 
        lista = new DefaultListModel();
        jMenuItemEditarPropiedad.setEnabled(false);
        jMenuItemEliminarPropiedad.setEnabled(false);
        jMenuItemCopiarPropiedad.setEnabled(false);
        jMenuItemGuardarPropiedad.setEnabled(false);
        jMenuItemVaciarLista.setEnabled(false);
        propiedadAPegar = new String("");
        propiedadAEditar = new String("");
        
        
        KeyListenerUIModelo keyListenerUIModelo = new KeyListenerUIModelo(this);
        contenedorTextoModelo.addKeyListener(keyListenerUIModelo);

        ActionListenerUIModelo actionListenerUIModelo = new ActionListenerUIModelo(this,parent);
        buttonAnalizarSintaxis.addActionListener(actionListenerUIModelo);
        jMenuItemCortar.addActionListener(actionListenerUIModelo);
        jMenuItemCopiar.addActionListener(actionListenerUIModelo);
        jMenuItemCopiarPropiedad.addActionListener(actionListenerUIModelo);
        jMenuItemPegar.addActionListener(actionListenerUIModelo);
        jMenuItemDOT.addActionListener(actionListenerUIModelo);
        jMenuItemBDD.addActionListener(actionListenerUIModelo);
        jMenuItemSalir.addActionListener(actionListenerUIModelo);
        jMenuItemGuardar.addActionListener(actionListenerUIModelo);
        jMenuItemGuardarComo.addActionListener(actionListenerUIModelo);
        jMenuItemGuardarPropiedad.addActionListener(actionListenerUIModelo);
        jMenuItemAbrir.addActionListener(actionListenerUIModelo);
        jMenuItemNuevo.addActionListener(actionListenerUIModelo);
        jMenuItemMaximizar.addActionListener(actionListenerUIModelo);
        jMenuItemNuevaPropiedad.addActionListener(actionListenerUIModelo);
        jMenuItemEliminarPropiedad.addActionListener(actionListenerUIModelo);
        jMenuItemVaciarLista.addActionListener(actionListenerUIModelo);
        jMenuItemEditarPropiedad.addActionListener(actionListenerUIModelo);
        jMenuItemPopupGuardar.addActionListener(actionListenerUIModelo);
        jMenuItemPopupCopiarPropiedad.addActionListener(actionListenerUIModelo);
        jMenuItemPopupEditar.addActionListener(actionListenerUIModelo);
        jMenuItemAbrirPropiedad.addActionListener(actionListenerUIModelo);
        jButtonChequear.addActionListener(actionListenerUIModelo);
        ListSelectionListenerUIModelo listSelectionListenerUIModelo = new ListSelectionListenerUIModelo(this);
        listaPropiedad.addListSelectionListener(listSelectionListenerUIModelo);
        WindowListenerUIModelo windowListenerUIModelo = new WindowListenerUIModelo(this);
        this.addWindowListener(windowListenerUIModelo);

    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UIModelo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UIModelo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UIModelo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UIModelo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UIModelo dialog = new UIModelo(new GUIPrincipal(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button buttonAnalizarSintaxis;
    private java.awt.Button jButtonChequear;
    private javax.swing.JInternalFrame jInternalFrameModelo;
    private javax.swing.JInternalFrame jInternalFramePropiedad;
    private javax.swing.JMenu jMenuArchivo;
    private javax.swing.JMenuBar jMenuBarModelo;
    private javax.swing.JMenuBar jMenuBarPropiedad;
    private static javax.swing.JMenu jMenuEditar;
    private static javax.swing.JMenu jMenuEditarLista;
    private javax.swing.JMenuItem jMenuItemAbrir;
    private javax.swing.JMenuItem jMenuItemAbrirPropiedad;
    private javax.swing.JMenuItem jMenuItemBDD;
    private javax.swing.JMenuItem jMenuItemCopiar;
    private javax.swing.JMenuItem jMenuItemCopiarPropiedad;
    private javax.swing.JMenuItem jMenuItemCortar;
    private javax.swing.JMenuItem jMenuItemDOT;
    private javax.swing.JMenuItem jMenuItemEditarPropiedad;
    private javax.swing.JMenuItem jMenuItemEliminarPropiedad;
    private javax.swing.JMenuItem jMenuItemGuardar;
    private javax.swing.JMenuItem jMenuItemGuardarComo;
    private javax.swing.JMenuItem jMenuItemGuardarPropiedad;
    private javax.swing.JMenuItem jMenuItemMaximizar;
    private javax.swing.JMenuItem jMenuItemNuevaPropiedad;
    private javax.swing.JMenuItem jMenuItemNuevo;
    private javax.swing.JMenuItem jMenuItemPegar;
    private javax.swing.JMenuItem jMenuItemPopupCopiarPropiedad;
    private javax.swing.JMenuItem jMenuItemPopupEditar;
    private javax.swing.JMenuItem jMenuItemPopupGuardar;
    private javax.swing.JMenuItem jMenuItemSalir;
    private javax.swing.JMenuItem jMenuItemVaciarLista;
    private javax.swing.JMenu jMenuVentana;
    private javax.swing.JMenu jMenuVer;
    private javax.swing.JPanel jPanelAnalizar;
    private javax.swing.JPanel jPanelChequear;
    private javax.swing.JPanel jPanelListaPropiedades;
    private javax.swing.JPopupMenu jPopupMenuEditarGuardarPropiedad;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane;
    private javax.swing.JTabbedPane jTabbedPane;
    private javax.swing.JList listaPropiedad;
    // End of variables declaration//GEN-END:variables
    private JTextPane jTextPaneLineas;//Panel para el número de líneas
    
    
   
    
    
    private String rutaArchivoActual;//Almacena el path del modelo que se abre 
                                     //en la ventana, si fue modelo abierto de 
                                     //archivo existente. Si el modelo no se 
                                     //abrió desde un archivo .mod existente, 
                                     //sino que se eligió la opción de escritura
                                     //de modelo, almacena la cadena vacía
    
    
    private BDD bddInicializacion;//Almacena el BDD de la inicialización del 
                                  //modelo
    
    
    private BDD bddModelo;//Almacena el BDD del modelo
    
    private BDD bddNormal; //almacena el BDD normal
    
    private GUIPrincipal parent;//Almacena la instancia de la ventana principal 
                                //desde donde se abre esta instancia 'UIModelo'


    
    private JTextPane contenedorTextoModelo;//Contenedor de texto para 
                                            //especificar modelos
    
    
    private JPanel jPanelEditor;//Contenedor que contiene el contenedor de texto
                                //para especificar modelos
    
    
    private JScrollPane jScrollPaneEditor;//Contenedor con barra de
                                          //desplazamiento, que contiene el 
                                          //'jPanelEditor' y contiene el panel 
                                          //donde se visualizan los números de
                                          //línea del contenedor de texto que 
                                          //especifica modelos
    
    
    private JTextPane jTextPaneResultadoAnalisis;//Contenedor de texto que
                                                 // almacena resultado de
                                                 //análisis sintáctico y 
                                                 //semántico de un modelo,
                                                 //el DOT de un modelo, e
                                                 //información sobre errores
                                                 //en tiempo de ejecución que
                                                 //puedan ocurrir
    
    
    private JPanel jPanelResultadoAnalisis;//Contenedor que contiene 
                                           //'jTextPaneResultadoAnalisis'
    
    
    private JScrollPane jScrollPaneResultadoAnalisis;//Contenedor con barra de
                                                     //desplazamiento, que 
                                                     //contiene 
                                                     //'jPanelResultadoAnalisis'
    
    
    private int longitudTexto;//Almacena la longitud del texto del modelo
    
    
    private boolean esModeloEditado;//Registra si el modelo está siendo 
                                    //editado
    
    
    private DefaultListModel lista;//Almacena las propiedades agregadas
                                   //desde la pestaña modelo
    

    
    private List propiedadesGuardadas;//Almacena las propiedades guardadas
    
    private List lista_rutaPropiedad;//Almacena pares: propiedad-ruta del archivo que contiene la propiedad (si fue guardada)
                                     //de propiedades que guardadas en archivo y registradas en al ventana donde se manipulan propiedades dCTL
    
    private String resultadoAnalisisModelo;//Almacena el resultado del análisis léxico, sintáctico y semántico del modelo
    
    private String resultadoAnalisisPropiedad;//Almacena el resultado del análisis léxico, sintáctico y semántico de una propiedad de la lista de propiedades
    
    private  List vbleDecl;//Almacena las variables declaradas del modelo
    
    private String propiedadAEditar;//Almacena la propiedad a editar (en caso en que se elija editar una propiedad)
    
    private  String propiedadAPegar;//Almacena la propiedad a pegar (en caso en que se elija pegar una propiedad)

    private FormulaElement formula;//Almacena la estructura que representa una propiedad dCTL, que es entrada al Model Checker integrado
    

    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    


    public JTextPane getContenedorTextoModelo(){
        return contenedorTextoModelo;
    }
    
    public JTextPane getContendorTextoMuestraResultado(){
        return jTextPaneResultadoAnalisis;
    }
    

    public void setRutaArchivoActual(String ruta){
        rutaArchivoActual=ruta;
    }

    public String getRutaArchivoActual(){
        return rutaArchivoActual;
    }
    
    public DefaultListModel getLista(){
        return lista;
    }
      
    public List getLista_rutaPropiedad(){
        return lista_rutaPropiedad;
    }
    
    public JList getListaPropiedad(){
        return listaPropiedad;
    }
    
    public boolean getEsModeloEditado(){
        return esModeloEditado;
    }

    
    public List getPropiedadesGuardadas(){
        return propiedadesGuardadas;
    }

    public String getResultadoAnalisisPropiedad(){
        return resultadoAnalisisPropiedad;
    }
    
    public String getResultadoAnalisisModelo(){
        return resultadoAnalisisModelo;
    }
    
    public BDD getBDDInicializacion(){
        return bddInicializacion;
    }
    
    public BDD getBDDNormal(){
        return bddNormal;
    }
    
    public BDD getBDDModelo(){
        return bddModelo;
    }   
    
    public List getVbleDecl(){
        return vbleDecl;
    }
    
    public Button getButtonAnalizarSintaxis(){
        return buttonAnalizarSintaxis;
    }
    
    public JMenuItem getMenuItemCortar(){
        return jMenuItemCortar;
    }
    
    public JMenuItem getMenuItemCopiar(){
        return jMenuItemCopiar;
    }
    
    
    public JMenuItem getMenuItemCopiarPropiedad(){
        return jMenuItemCopiarPropiedad;
    }
    
    public JMenuItem getMenuItemPegar(){
        return jMenuItemPegar;
    }

    public JMenuItem getMenuItemDOT(){
        return jMenuItemDOT;
    }

    public JMenuItem getMenuItemBDD(){
        return jMenuItemBDD;
    }
    
    public JMenuItem getMenuItemSalir(){
        return jMenuItemSalir;
    }
    
    public JMenuItem getMenuItemGuardar(){
        return jMenuItemGuardar;
    }
    
    public JMenuItem getMenuItemGuardarComo(){
        return jMenuItemGuardarComo;
    }
    
    public JMenuItem getMenuItemGuardarPropiedad(){
        return jMenuItemGuardarPropiedad;
    }
    

    public JMenuItem getMenuItemAbrir(){
        return jMenuItemAbrir;
    }

    public JMenuItem getMenuItemNuevo(){
        return jMenuItemNuevo;
    }

    public JMenuItem getMenuItemMaximizar(){
        return jMenuItemMaximizar;
    }
    
    public JMenuItem getMenuItemNuevaPropiedad(){
        return jMenuItemNuevaPropiedad;
    }
       
    public JMenuItem getMenuItemEliminarPropiedad(){
        return jMenuItemEliminarPropiedad;
    }
    
    public JMenuItem getMenuItemVaciarLista(){
        return jMenuItemVaciarLista;
    }
    
    
    public JMenuItem getMenuItemEditarPropiedad(){
        return jMenuItemEditarPropiedad;
    }

    public JMenuItem getMenuItemPopupGuardar(){
        return jMenuItemPopupGuardar;
    }
    
    public JMenuItem getMenuItemPopupCopiarPropiedad(){
        return jMenuItemPopupCopiarPropiedad;
    }            
            
    public JMenuItem getMenuItemPopupEditar(){
        return jMenuItemPopupEditar;
    }

    public JMenuItem getMenuItemAbrirPropiedad(){
        return jMenuItemAbrirPropiedad;
    }

    public Button getButtonChequear(){
        return jButtonChequear;
    }
    
    
    public void setBDDInicializacion(BDD bddInicializacion){
        this.bddInicializacion = bddInicializacion;
    }
    
    public void setBDDNormal(BDD bddNormal){
        this.bddNormal = bddNormal;
    }
    
    public void setBDDModelo(BDD bddModelo){
        this.bddModelo = bddModelo;
    }
    
    public void setVbleDecl(List vbleDecl){
        this.vbleDecl = vbleDecl;
    }
    
    public void setResultadoAnalisisModelo(String resultadoAnalisisModelo){
        this.resultadoAnalisisModelo=resultadoAnalisisModelo;
    }

    public int getLongitudTexto(){
        return longitudTexto;
    }
    
    public void setLongitudTexto(int longitudTexto){
        this.longitudTexto=longitudTexto;
    }

     public String getPropiedadAEditar(){
        return propiedadAEditar;
    }
    
    public void setPropiedadAEditar(String propiedadAEditar){
        this.propiedadAEditar = propiedadAEditar;
    }
    
    public String getPropiedadAPegar(){
        return propiedadAPegar;
    }
    
    public void setPropiedadAPegar(String propiedadAPegar){
        this.propiedadAPegar = propiedadAPegar;
    }
    
    public void setEsModeloEditado(boolean esModeloEditado){
        this.esModeloEditado=esModeloEditado;
    }
    
    public FormulaElement getFormula(){
        return formula;
    }
    
    public void setFormula(FormulaElement formula){
        this.formula = formula;
    }
    
     public void setLista_rutaPropiedad(List lista){
        lista_rutaPropiedad = lista;
    }

}
