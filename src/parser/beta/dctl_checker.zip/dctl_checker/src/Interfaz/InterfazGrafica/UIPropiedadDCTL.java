package Interfaz.InterfazGrafica;


import Interfaz.Eventos.EventosUIPropiedad.ActionListenerUIPropiedad;
import Interfaz.Eventos.EventosUIPropiedad.WindowListenerUIPropiedad;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JTextField;




/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class UIPropiedadDCTL extends javax.swing.JDialog {


    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public UIPropiedadDCTL(UIModelo parent, boolean modal, ActionEvent actionEventModelo) {
        super(parent, modal);
        this.setLocationRelativeTo(parent);
        initComponents();
        ui_modelo = parent;
        this.actionEventModelo = actionEventModelo;
        if((actionEventModelo.getSource()==ui_modelo.getMenuItemEditarPropiedad())||(actionEventModelo.getSource()==ui_modelo.getMenuItemPopupEditar())){
            String propiedad=(String)ui_modelo.getListaPropiedad().getSelectedValue();
            propiedad=propiedad.replaceAll("<html><font color=gray>", "");
            propiedad=propiedad.replaceAll("<html><font color=black>", "");
            propiedad=propiedad.replaceAll("</font></html>", "");
            jTextFieldPriopiedad.setText(propiedad);
        }
        ActionListenerUIPropiedad actionListenerUIPropiedad = new ActionListenerUIPropiedad(this,ui_modelo,actionEventModelo);
        jButtonGuardarPropiedad.addActionListener(actionListenerUIPropiedad);
        jButtonSalir.addActionListener(actionListenerUIPropiedad);
        jMenuItemCopiarPropiedad.addActionListener(actionListenerUIPropiedad);
        jMenuItemCortarPropiedad.addActionListener(actionListenerUIPropiedad);
        jMenuItemPegarPropiedad.addActionListener(actionListenerUIPropiedad);
        jMenuItemPopupCopiarPropiedad.addActionListener(actionListenerUIPropiedad);
        jMenuItemPopupCortarPropiedad.addActionListener(actionListenerUIPropiedad);
        jMenuItemPopupPegarPropiedad.addActionListener(actionListenerUIPropiedad);
        WindowListenerUIPropiedad windowListenerUIPropiedad = new WindowListenerUIPropiedad(ui_modelo, this);
        this.addWindowListener(windowListenerUIPropiedad);
        
        
    }
    
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ---MÉTODO QUE INICIALIZA LAS CARACTERÍSTICAS GRÁFICAS DE LA VENTANA---
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenuCopiarPegarCortarPropiedad = new javax.swing.JPopupMenu();
        jMenuItemPopupCopiarPropiedad = new javax.swing.JMenuItem();
        jMenuItemPopupCortarPropiedad = new javax.swing.JMenuItem();
        jMenuItemPopupPegarPropiedad = new javax.swing.JMenuItem();
        jPanelTextPropiedad = new javax.swing.JPanel();
        jButtonGuardarPropiedad = new javax.swing.JButton();
        jTextFieldPriopiedad = new javax.swing.JTextField();
        jButtonSalir = new javax.swing.JButton();
        jMenuBarEditar = new javax.swing.JMenuBar();
        jMenuEditarpropiedad = new javax.swing.JMenu();
        jMenuItemCopiarPropiedad = new javax.swing.JMenuItem();
        jMenuItemCortarPropiedad = new javax.swing.JMenuItem();
        jMenuItemPegarPropiedad = new javax.swing.JMenuItem();
        jMenuItemSalir = new javax.swing.JMenuItem();

        jMenuItemPopupCopiarPropiedad.setText("Copiar");
        jPopupMenuCopiarPegarCortarPropiedad.add(jMenuItemPopupCopiarPropiedad);

        jMenuItemPopupCortarPropiedad.setText("Cortar");
        jPopupMenuCopiarPegarCortarPropiedad.add(jMenuItemPopupCortarPropiedad);

        jMenuItemPopupPegarPropiedad.setText("Pegar");
        jPopupMenuCopiarPegarCortarPropiedad.add(jMenuItemPopupPegarPropiedad);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Propiedad dCTL");
        setResizable(false);

        jPanelTextPropiedad.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButtonGuardarPropiedad.setText("Guardar");

        jButtonSalir.setText("Salir");

        javax.swing.GroupLayout jPanelTextPropiedadLayout = new javax.swing.GroupLayout(jPanelTextPropiedad);
        jPanelTextPropiedad.setLayout(jPanelTextPropiedadLayout);
        jPanelTextPropiedadLayout.setHorizontalGroup(
            jPanelTextPropiedadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelTextPropiedadLayout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanelTextPropiedadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextFieldPriopiedad)
                    .addGroup(jPanelTextPropiedadLayout.createSequentialGroup()
                        .addComponent(jButtonGuardarPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(89, 89, 89)
                        .addComponent(jButtonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanelTextPropiedadLayout.setVerticalGroup(
            jPanelTextPropiedadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTextPropiedadLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jTextFieldPriopiedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(jPanelTextPropiedadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGuardarPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        getContentPane().add(jPanelTextPropiedad, java.awt.BorderLayout.CENTER);

        jMenuEditarpropiedad.setText("Editar");

        jMenuItemCopiarPropiedad.setText("Copiar");
        jMenuEditarpropiedad.add(jMenuItemCopiarPropiedad);

        jMenuItemCortarPropiedad.setText("Cortar");
        jMenuEditarpropiedad.add(jMenuItemCortarPropiedad);

        jMenuItemPegarPropiedad.setText("Pegar");
        jMenuEditarpropiedad.add(jMenuItemPegarPropiedad);

        jMenuItemSalir.setText("Salir");
        jMenuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSalirActionPerformed(evt);
            }
        });
        jMenuEditarpropiedad.add(jMenuItemSalir);

        jMenuBarEditar.add(jMenuEditarpropiedad);

        setJMenuBar(jMenuBarEditar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_jMenuItemSalirActionPerformed

   
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonGuardarPropiedad;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JMenuBar jMenuBarEditar;
    private javax.swing.JMenu jMenuEditarpropiedad;
    private javax.swing.JMenuItem jMenuItemCopiarPropiedad;
    private javax.swing.JMenuItem jMenuItemCortarPropiedad;
    private javax.swing.JMenuItem jMenuItemPegarPropiedad;
    private static javax.swing.JMenuItem jMenuItemPopupCopiarPropiedad;
    private static javax.swing.JMenuItem jMenuItemPopupCortarPropiedad;
    private static javax.swing.JMenuItem jMenuItemPopupPegarPropiedad;
    private javax.swing.JMenuItem jMenuItemSalir;
    private javax.swing.JPanel jPanelTextPropiedad;
    private javax.swing.JPopupMenu jPopupMenuCopiarPegarCortarPropiedad;
    private static javax.swing.JTextField jTextFieldPriopiedad;
    // End of variables declaration//GEN-END:variables
    private UIModelo ui_modelo;
    private ActionEvent actionEventModelo;
 

    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    public String getPropiedad(){
        return jTextFieldPriopiedad.getText();
    }
    
    public JTextField getContenedorTextoPropiedad(){
        return jTextFieldPriopiedad;
    }


    public JButton getButtonGuardarPropiedad(){
        return jButtonGuardarPropiedad;
    }
    
    public JMenuItem getMenuItemCopiarPropiedad(){
        return jMenuItemCopiarPropiedad;
    }
    
    public JMenuItem getMenuItemCortarPropiedad(){
        return jMenuItemCortarPropiedad;
    }
    
    public JMenuItem getMenuItemPegarPropiedad(){
        return jMenuItemPegarPropiedad;
    }
    
    public JMenuItem getMenuItemPopupCopiarPropiedad(){
        return jMenuItemPopupCopiarPropiedad;
    }
    
    public JMenuItem getMenuItemPopupCortarPropiedad(){
        return jMenuItemPopupCortarPropiedad;
    }
    
    public JMenuItem getMenuItemPopupPegarPropiedad(){
        return jMenuItemPopupPegarPropiedad;
    }
    
    public JButton getButtonSalir(){
        return jButtonSalir;
    }
}
