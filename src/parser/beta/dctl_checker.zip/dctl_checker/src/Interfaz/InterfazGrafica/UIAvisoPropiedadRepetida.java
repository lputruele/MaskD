package Interfaz.InterfazGrafica;

import javax.swing.JDialog;



/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class UIAvisoPropiedadRepetida extends javax.swing.JDialog {
        
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public UIAvisoPropiedadRepetida(JDialog parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(parent);
    }


    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ---MÉTODO QUE INICIALIZA LAS CARACTERÍSTICAS GRÁFICAS DE LA VENTANA---
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new javax.swing.JPanel();
        jPanelBotonAceptar = new javax.swing.JPanel();
        botonAceptar = new javax.swing.JButton();
        jLabelAviso = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(java.awt.Color.white);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });

        jPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel.setLayout(new java.awt.BorderLayout());

        botonAceptar.setText("Aceptar");
        botonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarActionPerformed(evt);
            }
        });
        jPanelBotonAceptar.add(botonAceptar);
        getRootPane().setDefaultButton(botonAceptar);

        jPanel.add(jPanelBotonAceptar, java.awt.BorderLayout.SOUTH);

        jLabelAviso.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelAviso.setText("Propiedad/es previamente registrada/s ó vacía.");
        jPanel.add(jLabelAviso, java.awt.BorderLayout.NORTH);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("No se permite propiedades repetidas en la lista");
        jPanel.add(jLabel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    /*
      MÉTODO QUE SE INVOCA AL HACER CLIC EN BOTÓN "ACEPTAR"
    */
    private void botonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarActionPerformed
        this.dispose();
    }//GEN-LAST:event_botonAceptarActionPerformed
    
    
    /*
      MÉTODO QUE SE INVOCA AL HACER CLIC EN CERRAR LA VENTANA DE AVISO
    */
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        this.dispose();
    }//GEN-LAST:event_closeDialog


    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAceptar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelAviso;
    private javax.swing.JPanel jPanel;
    private javax.swing.JPanel jPanelBotonAceptar;
    // End of variables declaration//GEN-END:variables


}
