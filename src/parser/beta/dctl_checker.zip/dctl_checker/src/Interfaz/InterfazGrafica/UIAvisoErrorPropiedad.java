package Interfaz.InterfazGrafica;

import AnalizadorModelo.AuxiliarModelo.Par;
import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import Interfaz.AuxiliarInterfaz.ManipulacionListas;
import Interfaz.Eventos.EventosUIPropiedad.EventosPropiedad;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;




/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class UIAvisoErrorPropiedad extends javax.swing.JDialog {
        public EventosPropiedad eventosPropiedad;
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------CONSTRUCTOR DE LA VENTANA---------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public UIAvisoErrorPropiedad(UIModelo uiModelo, UIPropiedadDCTL parent, boolean modal, EventosPropiedad eventosPropiedad) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(parent);
        this.uiModelo = uiModelo;
        this.eventosPropiedad= eventosPropiedad;
        uiPropiedad_dCTL=parent;
        this.manipulacionArchivos = new ManipulacionArchivos(uiModelo);
        
    }


    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ---MÉTODO QUE INICIALIZA LAS CARACTERÍSTICAS GRÁFICAS DE LA VENTANA---
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new javax.swing.JPanel();
        jLabelAviso2 = new javax.swing.JLabel();
        botonAceptar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        jLabelAviso1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(java.awt.Color.white);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(450, 100));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });

        jPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabelAviso2.setText("¿Guardar de todos modos?");

        botonAceptar.setText("Aceptar");
        botonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarActionPerformed(evt);
            }
        });

        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        jLabelAviso1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addComponent(jLabelAviso1, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGap(138, 138, 138)
                .addComponent(jLabelAviso2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelAviso1, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelAviso2)
                .addGap(5, 5, 5)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptar)
                    .addComponent(botonCancelar))
                .addGap(42, 42, 42))
        );

        getRootPane().setDefaultButton(botonAceptar);
        getRootPane().setDefaultButton(botonAceptar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
   
    
    /*
      MÉTODO QUE SE INVOCA AL HACER CLIC EN CERRAR LA VENTANA DE AVISO
    */
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        this.dispose();
    }//GEN-LAST:event_closeDialog

    
    /*
      MÉTODO QUE SE INVOCA AL HACER CLIC EN BOTÓN "CANCELAR"
    */
    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        
        /*
           Si la propiedad que se cancela guardar fue propiedad editada, se elimina de la lista 
           de pares donde cada par contiene una propiedad guardada y el directorio donde se 
           encuentra el archivo que contiene dicha propiedad, el par que contiene la propiedad a
           editar, en caso que la propiedad a editar haya sido guardada en archivo. En otro
           caso, el método eliminar no produce cambios
        */
        Par par = ManipulacionListas.buscar_listaRutaPropiedad(uiModelo.getLista_rutaPropiedad(), uiModelo.getPropiedadAEditar());
        uiModelo.setLista_rutaPropiedad(ManipulacionListas.eliminar_rutaPropiedad(uiModelo.getLista_rutaPropiedad(),par));
        this.dispose();
    }//GEN-LAST:event_botonCancelarActionPerformed


    /*
      MÉTODO QUE SE INVOCA AL HACER CLIC EN BOTÓN "ACEPTAR"
    */
    private void botonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarActionPerformed
            try {
                /*
                   Se almacena la propiedad léxica, sintáctica y/o semánticamente incorrecta,
                   a guardar 
                */
                String propiedad = uiPropiedad_dCTL.getContenedorTextoPropiedad().getText().trim();
                if(!propiedad.equals("")){//Si la propiedad no es vacía
                    
                        /*
                          De la lista de pares donde cada par contiene una 
                          propiedad guardada y el directorio donde se encuentra el archivo
                          que contiene dicha propiedad, se obtiene el par que contiene la 
                          propiedad a guardar
                        */
                        Par par = ManipulacionListas.buscar_listaRutaPropiedad(uiModelo.getLista_rutaPropiedad(), uiModelo.getPropiedadAEditar());
                        if(((String)par.getSegundo()).equals("")){//Si la propiedad a editar ó la
                                                                  //propiedad registrada, que se 
                                                                  //quiere guardar, no está en 
                                                                  //algún par de la lista de pares    
                             
                            /*
                               Se permite guardar la propiedad en un directorio
                            */
                             par = manipulacionArchivos.guardarComo("<html><font color=black>"+propiedad+"</font></html>","dCTL");
                             if(!par.getPrimero().equals("")){//Si se guardó la propiedad en archivo
                                
                                /*
                                  Se reemplaza de la lista de propiedades registradas, el color 
                                  de la propiedad guardada en archivo, por color negro.
                                  Y se agrega en la lista de pares, el par que contiene la propiedad
                                  guardada en archivo y el directorio elegido para el mismo  
                                */ 
                                uiModelo.getLista().set(uiModelo.getLista().indexOf("<html><font color=gray>"+propiedad+"</font></html>"), "<html><font color=black>"+propiedad+"</font></html>");
                                uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                                par.setPrimero(propiedad);
                                uiModelo.getLista_rutaPropiedad().add(par);
                                uiModelo.getPropiedadesGuardadas().add(propiedad);
                             }
                             if(par.getPrimero().equals("")){//Si no se guardó la propiedad en archivo
                                uiModelo.getLista().set(uiModelo.getLista().indexOf("<html><font color=gray>"+propiedad+"</font></html>"), "<html><font color=gray>"+propiedad+"</font></html>");
                             } 
                        }
                        else{//Si la propiedad a editar, que se quiere guardar, está en algún par 
                             //de la lista de pares (nunca entra a 'else' si fue propiedad
                             //agregada y no editada, a guardar)   
                            
                            /*
                               Se reemplaza de la lista de propiedades registradas, el color 
                               de la propiedad guardada en archivo, por color negro.
                               Se reemplaza de la lista de pares, el par que contiene la 
                               propiedad a editar y el directorio donde se encuentra el archivo,
                               por el par que contiene la propiedad editada por el mismo 
                               directorio del archivo que contiene la propiedad a editar.
                               Se reescribe el archivo que contiene la propiedad a editar, por
                               la propiedad guardada
                            */ 
                            uiModelo.getLista().set(uiModelo.getLista().indexOf("<html><font color=gray>"+propiedad+"</font></html>"), "<html><font color=black>"+propiedad+"</font></html>");
                            uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                            uiModelo.getPropiedadesGuardadas().add(propiedad);
                            uiModelo.setLista_rutaPropiedad(ManipulacionListas.eliminar_rutaPropiedad(uiModelo.getLista_rutaPropiedad(),par));
                            par.setPrimero(propiedad);
                            uiModelo.getLista_rutaPropiedad().add(par);
                            manipulacionArchivos.guardar((String)par.getSegundo(), "<html><font color=black>"+propiedad+"</font></html>","dCTL");
                        } 
                    }
                this.dispose();
            } catch (IOException ex) {
                Logger.getLogger(UIAvisoErrorPropiedad.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_botonAceptarActionPerformed


    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAceptar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JLabel jLabelAviso1;
    private javax.swing.JLabel jLabelAviso2;
    private javax.swing.JPanel jPanel;
    // End of variables declaration//GEN-END:variables
    private UIModelo uiModelo;
    private UIPropiedadDCTL uiPropiedad_dCTL;
    private ManipulacionArchivos manipulacionArchivos;

    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    public void setError(String error){
        jLabelAviso1.setText(error);
    }
}
