package Interfaz.AuxiliarInterfaz;


import AnalizadorModelo.AuxiliarModelo.Par;
import Interfaz.InterfazGrafica.GUIPrincipal;
import Interfaz.InterfazGrafica.UIModelo;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.CodeSource;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.BadLocationException;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ManipulacionArchivos {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private GUIPrincipal guiPrincipal;
    private UIModelo uiModelo;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public ManipulacionArchivos(UIModelo uiModelo){
        this.uiModelo = uiModelo;
    }
    
    public ManipulacionArchivos(GUIPrincipal guiPrincipal){
        this.guiPrincipal = guiPrincipal;
    }
    
    public ManipulacionArchivos(){
    }
    
    
    /*
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
       ---------------------------MÉTODOS PÚBLICOS----------------------------
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
    */
    
    
    /*
       MÉTODO QUE SOBREESCRIBE EL CONTENIDO DEL ARCHIVO DADO COMO PARÁMETRO, 
       CON LA ESPECIFICACIÓN DEL MODELO 'texto' DADO COMO PARÁMETRO
    */
    public void escribirEnArchivo(File archivo,String texto) throws IOException{
        BufferedWriter out; 
        out = new BufferedWriter(new FileWriter(archivo));
        out.write(texto);
        out.close();   
    }
    
    
     /*
       MÉTODO QUE RETORNA EL CONTENIDO DEL ARCHIVO DADO COMO PARÁMETRO
    */
    public String obtenerContenidoArchivo(File file) throws IOException{ 
        FileInputStream fis = null;
        String content = null;
        FileReader reader = new FileReader(file);
        char[] chars = new char[(int) file.length()];
        reader.read(chars);
        content = new String(chars);
        reader.close();
        return content.trim();
    } 


  
  
    
   
    /*
       MÉTODO QUE CREA UN ARCHIVO DE NOMBRE Y EN RUTA DADA EN EL PARÁMETRO 
       'archivoBDD', QUE ALMACENA EL GRÁFICO DEL BDD GENERADO A PARTIR DEL 
       ARCHIVO DOT DE NOMBRE Y RUTA DADA EN EL PARÁMETRO 'archivoDOT' ASOCIADOS 
       AMBOS ARCHIVOS, A UN MODELO.
       
   */
    public void crearGraficoBDD(String archivoDOT,String archivoBDD) throws IOException{    
        String [] cmd = {"convert " + archivoDOT,"convert " + archivoDOT + " " + archivoBDD};
	    
    	//String [] cmd ={"convert /Users/cecilia/Documents/workspace/dctl_checker/DOT/maquina_inicModelo.dot /Users/cecilia/Documents/workspace/dctl_checker/Graficos_BDDs/maquina_inicModelo.pdf"};
    	System.out.println(cmd[0]);
	    System.out.println(cmd[1]);
	    //Runtime.getRuntime().exec(cmd[0],null,null);
	    try{
            Runtime.getRuntime().exec(cmd[1],null,null);
        }
	    catch(Exception e){
	    	System.out.println("exception" + e.toString());	
	    }
        
    }    


    /*
       MÉTODO QUE MUESTRA EN VENTANAS EXTERNAS AL SISTEMA, EL CONTENIDO DE UN 
       ARCHIVO. EL PARÁMETRO 'archivoBDD' INDICA LA RUTA, NOMBRE Y EXTENSIÓN DEL 
       ARCHIVO A MOSTRAR
   */
    public void mostrarArchivoBDD(String archivoBDD) throws IOException{
        File archivo = new File (archivoBDD);
        Desktop.getDesktop().open(archivo);
  }
    
  /*
       MÉTODO QUE ELIMINA UN ARCHIVO.
       EL PARÁMETRO 'archivo' INDICA LA RUTA, NOMBRE Y EXTENSIÓN DEL ARCHIVO
       A ELIMINAR
   */
    public void eliminarArchivo( String archivo){
            File fichero = new File(archivo);
            fichero.delete();
    }
    	
    
    /*
        MÉTODO QUE ALMACENA EN EL ARCHIVO CON RUTA, NOMBRE Y EXTENSIÓN DADO COMO
        PARÁMETRO 'rutaArchivoActual', EL CONTENIDO 'texto' DADO COMO PARÁMETRO.
        EL PARÁMETRO 'extension' INDICA LA EXTENSIÓN CON QUE DEBE GUARDARSE, EN
        CASO QUE 'rutaArchivoActual' NO ESTÉ REGISTRADO
     */
    public void guardar(String rutaArchivoActual, String texto, String extension) throws IOException{
            uiModelo.setRutaArchivoActual(rutaArchivoActual);
            File archivo;
            if(uiModelo.getRutaArchivoActual().endsWith("."+extension)){
                archivo = new File(rutaArchivoActual);
            }
            else{
                archivo = new File(rutaArchivoActual+"."+extension);
            }
            escribirEnArchivo(archivo,texto);
            uiModelo.setRutaArchivoActual(rutaArchivoActual);
    }
     
    /*
       MÉTODO QUE GUARDA O REESCRIBE UN ARCHIVO EXISTENTE CON EL CONTENIDO
       'texto' DADO COMO PARÁMETRO Y DE EXTENSIÓN DADA COMO PARÁMETRO.
       SE GUARDA EL ARCHIVO EN EL DIRECTORIO ELEGIDO POR EL USUARIO
    */
    public Par guardarComo(String texto, String extension) throws IOException{
        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setAcceptAllFileFilterUsed(false);
        jFileChooser.setFileFilter(new FileNameExtensionFilter("todos los archivos *."+extension, extension,extension));
        int resultado = jFileChooser.showSaveDialog(uiModelo);
        String archivo = ""; 
        String ruta = "";
        if(resultado==JFileChooser.APPROVE_OPTION){ 
           
            archivo=(jFileChooser.getSelectedFile().toString());
            ruta = jFileChooser.getSelectedFile().getAbsolutePath();
            uiModelo.setRutaArchivoActual(archivo);
            if(!(archivo.endsWith("."+extension))){
                archivo = archivo +"."+extension;
            } 
          
            File nuevoArchivo = new File(archivo);
            escribirEnArchivo(nuevoArchivo,texto);
             
        }
        Par par = new Par(archivo,ruta);
        return par;
            
    }
    
    /*
       MÉTODO QUE ABRE INSTANCIAS DE UIModelo, UNA PARA CADA ARCHIVO DE 
       EXTENSIÓN .mod SELECCIONADO A ABRIR. SE ABREN ARCHIVOS DEL DIRECTORIO 
       ELEGIDO POR EL USUARIO
    */
    public File[] abrirArchivos(JDialog ventana) throws IOException, BadLocationException{
        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setAcceptAllFileFilterUsed(false);
        jFileChooser.setFileFilter(new FileNameExtensionFilter("todos los archivos *.mod", "mod","mod"));
        jFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (!jFileChooser.isMultiSelectionEnabled()) {
            jFileChooser.setMultiSelectionEnabled(true);
        }
        int resultado = jFileChooser.showOpenDialog(ventana);
        File[] ficheros=null;
        switch(resultado){
            case JFileChooser.APPROVE_OPTION://Si se presiona botón Aceptar
                 {
                      /*Se almacenan los ficheros seleccionados, en 'ficheros'*/
                      ficheros = jFileChooser.getSelectedFiles();
                       
            }
            case JFileChooser.CANCEL_OPTION://Si se presiona botón Cancelar
                                              {
                                                   jFileChooser.removeAll();
                                              }
        }
        return ficheros;
    }
    
    
    /*
       MÉTODO QUE DADO LA RUTA PARCIAL DE UN ARCHIVO, DADA COMO PARÁMETRO, 
       RETORNA LA RUTA ABSOLUTA DEL MISMO:
       'ruta'= directorio_1/directorio_2/.../directorio_j/.../nombreArchivo.extensión
       ES LA RUTA ABOSLUTA RETORNADA, ENTONCES
       'subruta' DADA COMO PARÁMETRO = /directorio_j/.../nombreArchivo.extensión
    */
    public String buscarRuta(String subruta){
        File jarFile=null;
        String ruta = "";
        try {
            CodeSource codeSource = this.getClass().getProtectionDomain().getCodeSource();
            jarFile = new File(codeSource.getLocation().toURI().getPath());
        } 
        catch (URISyntaxException ex) {
            Logger.getLogger(GUIPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        ruta = jarFile.getParentFile().getPath();
        ruta = ruta + subruta;
        return ruta;
    }
    
    
}
