package Interfaz.AuxiliarInterfaz;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class PanelConFondo extends javax.swing.JPanel {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    
    /* Almacena ruta y nombre y extensión del archivo de fondo */
    private String ruta_nombre_extension;
    
    /* Almacena la imágen */
    private Image imagen;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public PanelConFondo(String ruta_nombre_extension){    
        super();
        this.ruta_nombre_extension = ruta_nombre_extension;
        
    }    

    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     ---------REDEFINICIÓN DEL MÉTODO paint(Graphics g) DE LA CLASE--------
     --------------------------------JPanel--------------------------------
     ---------------------------------------------------------------------- 
    */
    /* Método que en todo momento muestra la imágen de fondo */
    public void paint(Graphics g){
       Dimension dimension = getSize();//Almacena el tamaño del panel en todo momento
       imagen = new ImageIcon(ruta_nombre_extension).getImage();//Almacena la imágen en todo momento 
       g.drawImage(imagen,0,0,dimension.width,dimension.height, null);//Se "pinta" la imágen 
                                                                      //almacenada con la dimensión 
                                                                      //actual del panel                
        setOpaque(false);//Se indica que el panel es transparente para que se vea la imágen
        super.paint(g);//Se "pinta" la imágen en el panel
       
    }    
}  