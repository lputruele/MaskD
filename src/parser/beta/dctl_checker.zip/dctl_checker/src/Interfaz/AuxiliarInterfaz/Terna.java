package Interfaz.AuxiliarInterfaz;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class Terna {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private Object primero;//Almacena primer elemento de la terna
    private Object segundo;//Almacena segundo elemento de la terna
    private Object tercero;//Almacena segundo elemento de la terna

    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public Terna(Object primero, Object segundo, Object tercero){
        this.primero=primero;
        this.segundo=segundo;
        this.tercero=tercero;
    }
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    
    
    public Object getPrimero(){
        return primero;
    }
    
    
    public Object getSegundo(){
        return segundo;
    }
    
    public Object getTercero(){
        return tercero;
    }
    
    
    public void setPrimero(Object primero){
        this.primero=primero;
    }
    
    
    public void setSegundo(Object segundo){
        this.segundo=segundo;
    }
    
    public void setTercero(Object tercero){
        this.tercero=tercero;
    }
    
}
