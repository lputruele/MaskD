/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz.AuxiliarInterfaz;

import AnalizadorModelo.AuxiliarModelo.Par;
import java.util.List;
import javax.swing.DefaultListModel;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ManipulacionListas {
 
    
    /*
        MÉTODO QUE DADO UNA LISTA DE PARES PASADA COMO PARÁMETRO, DONDE CADA PAR 
        ALMACENA UNA PROPIEDAD dCTL Y LA RUTA DE UN ARCHIVO QUE CONTIENE DICHA 
        PROPIEDAD GUARADA Y REGISTRADA EN LA LISTA DE PROPIEDADES DE UNA VENTANA 
        QUE PERMITE MANIPULAR PROPIEDADES dCTL, Y DADO UNA PROPIEDAD dCTL PASADA
        COMO PARÁMETRO, RETONA EL PAR DE LA LISTA QUE CONTIENE LA PROPIEDAD DADA
        COMO PARÁMETRO. SI LA MISMA NO ESTÁ CONTENIDA EN LA LISTA, RETORNA EL 
        PAR QUE CONTIENE LA PROPIEDAD DADA COMO PARÁMETRO Y LA RUTA ""
    */
    public static Par buscar_listaRutaPropiedad(List lista, String propiedad){
        boolean encontrado = false;
        String ruta = "";
        for(int i =0; i < lista.size() && !encontrado; i++){
            Par parCorriente = (Par) lista.get(i);
            if(((String)parCorriente.getPrimero()).equals(propiedad)){
                ruta = (String)parCorriente.getSegundo(); 
                encontrado = true;
            }
        }
        Par par = new Par(propiedad, ruta);
        return par;
    }
    
    
    /*
        MÉTODO QUE DADO COMO PARÁMETRO, LA LISTA DE PROPIEDADES REGISTRADAS EN 
        LA VENTANA QUE PERMITE MANIPULAR PROPIEDADES dCTL, Y UNA PROPIEDAD dCTL,
        RETORNA EL ÍNDICE DE LA LISTA EN QUE ESTÁ LA PROPIEDAD dCTL PASADA COMO
        PARÁMETRO. SI DICHA PROPIEDAD NO SE ENCUENTRA EN LA LISTA, RETORNA -1
        
    */
    public static int buscarIndice_propiedadListModel(DefaultListModel lista, String propiedad){
        int indice = -1;
        boolean encontrado = false;
        for(int i = 0; i < lista.getSize() && !encontrado;i++ ){
            indice = i;
            if(((String)lista.get(i)).equals(propiedad)){
                encontrado = true;
            }
        }
        return indice;
    }
    
    
    /*
        MÉTODO QUE DADO LA LISTA DE PARES PASADA COMO PARÁMETRO, DONDE 
        CADA PAR ALMACENA UNA PROPIEDAD dCTL Y LA RUTA DE UN ARCHIVO QUE
        CONTIENE DICHA PROPIEDAD GUARADA Y REGISTRADA EN LA LISTA DE PROPIEDADES
        DE UNA VENTANA QUE PERMITE MANIPULAR PROPIEDADES dCTL, ELIMINA DE LA 
        LISTA, EL PAR QUE CONTIENE LA PROPIEDAD ALMACENADA EN EL PAR PASADO COMO
        PARÁMETRO
    */
    public static List eliminar_rutaPropiedad(List lista, Par par){
        boolean encontrado = false;
        for(int i = 0; i < lista.size() && !encontrado;i++ ){
            Par parCorriente = (Par) lista.get(i);
            if(((String)parCorriente.getPrimero()).equals((String)par.getPrimero())){
                lista.remove(parCorriente);
                encontrado = true;
            }
        }
        return lista;
    }
    
    
    /*
        MÉTODO QUE DADO LA LISTA DE PARES PASADA COMO PARÁMETRO, DONDE 
        CADA PAR ALMACENA UNA PROPIEDAD dCTL Y LA RUTA DE UN ARCHIVO QUE
        CONTIENE DICHA PROPIEDAD GUARADA Y REGISTRADA EN LA LISTA DE PROPIEDADES
        DE UNA VENTANA QUE PERMITE MANIPULAR PROPIEDADES dCTL, RETORNA TRUE SI
        LA PROPIEDAD PASADA COMO PARÁMETRO ESTÁ ALMACENADA EN ALGÚN PAR DE LA
        LISTA. EN CASO CONTRARIO RETORNA FALSE
    */
    public static boolean contiene(List lista, String propiedad){
        boolean encontrado = false;
        for(int i = 0; i < lista.size() && !encontrado;i++ ){
            if(((String)lista.get(i)).equals(propiedad)){
                encontrado = true;
            }
        }
        return encontrado;
    } 
    
}
