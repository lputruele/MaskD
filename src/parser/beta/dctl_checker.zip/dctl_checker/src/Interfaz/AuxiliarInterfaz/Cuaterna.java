package Interfaz.AuxiliarInterfaz;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class Cuaterna {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private Object primero;//Almacena primer elemento de la terna
    private Object segundo;//Almacena segundo elemento de la terna
    private Object tercero;//Almacena tercer elemento de la terna
    private Object cuarto;//Almacena cuarto elemento de la terna
    private Object quinto;//Almacena quinto elemento de la terna
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public Cuaterna(Object primero, Object segundo, Object tercero,Object cuarto, Object quinto){
        this.primero=primero;
        this.segundo=segundo;
        this.tercero=tercero;
        this.cuarto=cuarto;
        this.quinto=quinto;
    }
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    
    
    public Object getPrimero(){
        return primero;
    }
    
    
    public Object getSegundo(){
        return segundo;
    }
    
    public Object getTercero(){
        return tercero;
    }
    
    public Object getCuarto(){
        return cuarto;
    }
    
    public Object getQuinto(){
        return quinto;
    }
    
    
    public void setPrimero(Object primero){
        this.primero=primero;
    }
    
    
    public void setSegundo(Object segundo){
        this.segundo=segundo;
    }
    
    public void setTercero(Object tercero){
        this.tercero=tercero;
    }
    
    public void setCuarto(Object cuarto){
        this.cuarto=cuarto;
    }
    
    public void setQuinto(Object quinto){
        this.quinto=quinto;
    }
    
}
