package Interfaz.AuxiliarInterfaz;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ConfiguracionTexto {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
     private static SimpleAttributeSet formatoPalabraReservada;//Formato de palabra 
                                                       //reservada
    
    
    private static SimpleAttributeSet formatoClasico;//Formato clásico, letra color 
                                              //negro, sin negrita. 
                                              //Para palabras no reservadas y 
                                              //para el DOT de la inicialización
    
    
    private static SimpleAttributeSet formatoComentario;//Formato de comentarios
    
    
    private static SimpleAttributeSet formatoNegrita;//Formato para resaltar el
                                                     //DOT del modelo
    
    
        
    private static List palabrasReservadas;//Lista que almacena las palabras
                                    //reservadas del lenguaje dCTL
    
    private static List separadoresDePalabras;//Lista que almacena los símbolos del
                                       //lenguaje dCTL, que son separadores de 
                                       //palabras
    
    
    /*
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
       ---------------------------MÉTODOS PÚBLICOS----------------------------
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
    */
    
    /*
       MÉTODO QUE DEFINE CARACTERÍSTICAS DE UN TEXTO, DEFINE FORMATOS, PALABRAS
       RESEVADAS, Y CADENAS DE CARACTERES QUE SEPARAN UNA PALABRA DE OTRA EN EL 
       TEXTO.
    */
    public static void configurar(){
        formatoPalabraReservada = new SimpleAttributeSet();
        formatoClasico = new SimpleAttributeSet();
        formatoComentario = new SimpleAttributeSet();
        formatoNegrita=new SimpleAttributeSet();
        StyleConstants.setBold(formatoPalabraReservada, true);
        StyleConstants.setBold(formatoClasico, false);
        StyleConstants.setBold(formatoComentario, false);
        StyleConstants.setFontSize(formatoPalabraReservada,12); 
        StyleConstants.setFontSize(formatoClasico,12);
        StyleConstants.setFontSize(formatoComentario,12);
        StyleConstants.setForeground(formatoPalabraReservada,Color.BLUE);
        StyleConstants.setForeground(formatoClasico,Color.BLACK);
        StyleConstants.setBold(formatoNegrita,true);
        StyleConstants.setFontSize(formatoNegrita, 12);
        StyleConstants.setForeground(formatoNegrita, Color.BLACK);
        StyleConstants.setForeground(formatoComentario,Color.GRAY);
        palabrasReservadas=obtenerListaDePalabrasReservadas();//Se almacenan las palabras reservadas en la lista
        separadoresDePalabras=obtenerListaSeparadoresDePalabras();//Se almacenan los separadores de palabras en la lista
    }
    
    
    /*
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
       ---------------------------MÉTODOS PRIVADOS----------------------------
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
    */
    
    
    /*
       MÉTODO QUE RETORNA LA LISTA CON LAS PALABRAS RESERVADAS DEL LENGUAJE
       DEL MODELO
    */
    private static List obtenerListaDePalabrasReservadas(){
        List lista = new LinkedList<String>();
        lista.add("TRUE");
        lista.add("FALSE");
        lista.add("INT");
        lista.add("BOOL");
        lista.add("INIT");
        lista.add("NORMATIVE");
        return lista;
    }
 
    
    /*
       MÉTODO QUE RETORNA LA LISTA CON LOS SÍMBOLOS DEL LENGUAJE
       DEL MODELO, QUE SON SEPARADORES DE PALABRAS
    */
    private static List obtenerListaSeparadoresDePalabras(){
        List lista = new LinkedList<String>();
        lista.add(":");
        lista.add(",");
        lista.add(";");
        lista.add("<");
        lista.add("=");
        lista.add("+");
        lista.add("-");
        lista.add("*");
        lista.add(">");
        lista.add("/");
        lista.add("!");
        lista.add("(");
        lista.add(")");
        lista.add("|");
        lista.add("&");
        lista.add(" ");
        lista.add("\n");
        lista.add("\t");
        return lista;
    }
    
    
      
    /*
       MÉTODO QUE DA FORMATO DETERMINADO, A LAS PALABRAS RESERVADAS DE UNA 
       SECCIÓN DE TEXTO DEL MODELO Y A LOS COMENTARIOS QUE HAYA EN LA 
       ESPECIFICACIÓN DEL MODELO. LA SECCIÓN DE TEXTO ES DADA CON LOS 
       PARÁMETROS
    */
    public static void actualizarColoreoPalabrasReservadas(int posicionInicio,int size, JTextPane contenedorTextoModelo) throws BadLocationException{
        /* 
           Se reconfigura la especificación del modelo, con formato clásico: 
           Sin negrita, color de letra negra y tamaño de letra 12
        */ 
         darFormatoDeTexto(posicionInicio,size,ConfiguracionTexto.getFormatoClasico(),contenedorTextoModelo);

        
        /*
           Se inicializa la posición del texto del modelo, desde donde se 
           comienza a dar formato a las palabras reservadas y comentarios, con
           el parámetro 'posicionInicio'
        */
        int posicionCorriente=posicionInicio;        
        
        while(posicionCorriente<posicionInicio+size){//Mientras la posición 
                                                     //desde donde se va a dar
                                                     //un formato de texto,
                                                     //no supere la posición de 
                                                     //la última letra de la 
                                                     //especificación del modelo
            
            /*
               Se obtiene la palabra corriente 
            */
            String palabra="";  
            while ((posicionCorriente<posicionInicio+size)&&(!(esSeparadorDePalabras(contenedorTextoModelo.getText().charAt(posicionCorriente),ConfiguracionTexto.getSeparadoresPalabras())))){ // !esSeparadorDePalabra sirve también si es comentario al principio, para que no avance
                palabra=palabra+(contenedorTextoModelo.getText().charAt(posicionCorriente));
                posicionCorriente++;
            } 
            /*
               Si es palabra reservada, se da formato de palabra reservada 
            */
            if(esPalabraReservada(palabra,ConfiguracionTexto.getPalabrasReservadas())){ 
                darFormatoDeTexto(posicionCorriente-palabra.length(),palabra.length(),ConfiguracionTexto.getFormatoPalabraReservada(),contenedorTextoModelo); 
            }

            /*
              Tratamiento para los separadores de palabras y comentarios que 
              hay hasta la próxima palabra. 
            */   
            String texto="";
            while ((posicionCorriente<posicionInicio+size)&&(esSeparadorDePalabras(contenedorTextoModelo.getText().charAt(posicionCorriente),ConfiguracionTexto.getSeparadoresPalabras()))){             
                /*
                  - Si una subcadena de los separadores de palabras que hay 
                    entre dos palabras, es un comentario, se da formato de
                    comentario a dicha subcadena
                  - Si una subcadena de los separadores de palabras que hay
                    entre dos palabras, no es un comentario, queda el formato
                    clásico de la reconfiguración de formato realizada al
                    comienzo del método
                  
                  'texto' va almacenando las  subcadenas de longitud 1 y 2, de  
                  los separadores de palabras que hay entre dos palabras,que se
                  van formando a medida que se avanza una posición en la 
                  especificación del modelo. 
                  'texto' de longitud 1, almacena el separador de palabra 
                  corriente, y 'texto' de longitud 2, almacena el separador de 
                  palabra inmediatamente anterior al separador de palabra 
                  corriente, seguido del separador de palabra corriente
                  Ejemplo, dado "a:BOOL;//declaración", 'texto' almacena:
                    - :
                    - ;
                    - ;/
                    - //  --> Se detecta comienzo de comentario simple
               */ 
               texto=texto+(contenedorTextoModelo.getText().charAt(posicionCorriente));
               if((esComentarioSimple(texto))||(esComentarioMultipleLinea(texto))){//Si 'texto' es comentario
                   String comentario="";
                   int i =posicionCorriente+1;
                   if(esComentarioSimple(texto)){//Si es comentario simple
                      
                       /* 
                          Se obtiene comentario simple
                       */
                       comentario="//";
                       while((i<posicionInicio + size)&&(contenedorTextoModelo.getText().charAt(i)!='\n')){
                           comentario = comentario + contenedorTextoModelo.getText().charAt(i);
                           i++;
                       }
                   }
                   if(esComentarioMultipleLinea(texto)){//Si es comentario múltiple línea
                     
                       /* 
                          Se obtiene comentario múltiple línea
                       */
                       comentario= "/*";
                       if(i == posicionInicio + size - 1){
                           comentario = comentario + contenedorTextoModelo.getText().charAt(i);
                       }
                       else {
                           while((i<posicionInicio + size - 1)&&((contenedorTextoModelo.getText().charAt(i)!='*')||(contenedorTextoModelo.getText().charAt(i+1)!='/'))){
                               comentario = comentario + contenedorTextoModelo.getText().charAt(i);
                               i++;
                           }
                           if((i<posicionInicio + size - 1)&&(contenedorTextoModelo.getText().charAt(i)=='*')&&(contenedorTextoModelo.getText().charAt(i+1)=='/')){
                               comentario=comentario+ "*/";
                           }
                           else {
                               comentario = comentario + contenedorTextoModelo.getText().charAt(i-1);
                           }
                       }
                   }
                   texto="";
                   /* 
                      - Se da formato de comentario, al comentario detectado
                      - Se avanza la posición en la especificación del modelo, 
                        de separadores tratados, hasta el fin del comentario
                   */
                   darFormatoDeTexto(posicionCorriente-1,comentario.length(),ConfiguracionTexto.getFormatoComentario(),contenedorTextoModelo);
                   posicionCorriente=posicionCorriente+comentario.length()-1;
               }
               else {//Si 'texto' no es comentario
                   
                   /* 
                      - 'texto' almacena el separador de palabra corriente.
                      - Se avanza una posición en la especificación del modelo,
                        luego de tratar el separador de palabra corriente
                   */
                   texto=(contenedorTextoModelo.getText().charAt(posicionCorriente))+"";
                   posicionCorriente++;
               }
           }
       }
   }
    
      
    /*
       MÉTODO QUE DA EL FORMATO EL FORMATO DE TEXTO 'formato', A LA 
       SECCIÓN DEL TEXTO DEL 'contenedorTexto' DEFINIDA POR 'posicionInicial' y 
       'size'
    */
    public static void darFormatoDeTexto(int posicionInicial, int size, SimpleAttributeSet formato, JTextPane contenedorTexto) throws BadLocationException{
        StyledDocument documentoConFormato = contenedorTexto.getStyledDocument();
        String palabra = documentoConFormato.getText(posicionInicial, size);
        documentoConFormato.setCharacterAttributes(posicionInicial, size, formato, true);
        contenedorTexto.setCharacterAttributes(ConfiguracionTexto.getFormatoClasico(), true);
    }
    
    
      /*
       MÉTODO QUE AGREGA TEXTO CON FORMATO DETERMINADO, EN UN CONTENEDOR DE
       TEXTO, EN UNA POSICIÓN DEL MISMO.
    */
    public static void agregarTexto(int where, String palabra, AttributeSet style, JTextPane contenedorTextoModelo) throws BadLocationException {
        Document doc = contenedorTextoModelo.getDocument();//getgetStyledDocument();
        doc.insertString(where >= 0 ? where : doc.getLength(), palabra, style);   
    }
     
             
    /*
       MÉTODO QUE DETERMINA SI EL SÍMBOLOS DADO COMO PARÁMETRO, ES UN SÍMBOLO
       DEL LENGUAJE DEL MODELO, QUE SEPARA PALABRAS.
    */
    private static boolean esSeparadorDePalabras(char simbolo, List separadoresDePalabras){
        return separadoresDePalabras.contains(simbolo+"");
    }
     
   
    /*
       MÉTODO QUE DETERMINA SI EL TEXTO PASADO COMO PARÁMETRO, ES PALABRA
       RESERVADA DEL LENGUAJE DEL MODELO.
    */
    private static boolean esPalabraReservada(String cadenaCorriente, List palabrasReservadas){
        return palabrasReservadas.contains(cadenaCorriente);
    }


    /*
       MÉTODO QUE RETORNA TRUE, SI EL TEXTO PASADO COMO PARÁMETRO, ES LA CADENA
       DE COMIENZO DE COMENTARIO SIMPLE, CASO CONTRARIO RETORNA FALSE.
    */
    private static boolean esComentarioSimple(String texto){
        return texto.equals("//");
    }
    
    
    /*
       MÉTODO QUE RETORNA TRUE, SI EL TEXTO PASADO COMO PARÁMETRO, ES LA CADENA
       DE COMIENZO DE COMENTARIO MÚLTIPLE LÍNEA, CASO CONTRARIO RETORNA FALSE.
    */
    private static boolean esComentarioMultipleLinea(String texto){
        return texto.equals("/*");
    }
    
    /* ---------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------- */
    /* ----------------------get() Y set() DE ATRIBUTOS---------------------- */
    /* ---------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------- */
    
    
    public static SimpleAttributeSet getFormatoPalabraReservada(){
        return formatoPalabraReservada;
    }
    
    
    public static SimpleAttributeSet getFormatoClasico(){
        return formatoClasico;
    }
    
    
    public static SimpleAttributeSet getFormatoComentario(){
        return formatoComentario;
    }
    
    
    public static SimpleAttributeSet getFormatoNegrita(){
        return formatoNegrita;
    }
    
    public static List getSeparadoresPalabras(){
        return separadoresDePalabras;
    }
    
    
    public static List getPalabrasReservadas(){
        return palabrasReservadas;
    }
            
}
