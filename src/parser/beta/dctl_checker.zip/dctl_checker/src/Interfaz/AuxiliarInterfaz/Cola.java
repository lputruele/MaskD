package Interfaz.AuxiliarInterfaz;

import java.util.Queue;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public interface Cola extends Queue{
    
    public Object obtenerUltimo();
    
    
}
