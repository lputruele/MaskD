package Interfaz.AuxiliarInterfaz;

import java.io.IOException;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class GeneracionLexerParser {
    /*
       MÉOTODO QUE CREA ARCHIVOS LEXER Y PARSER EN JAVA,
       A PARTIR DE LOS ARCHIVOS .jlex y .cup RESPECTIVAMENTE
    */
    public static void crearArchivo_lexer_parser(String origenLex, String origenCUP, String destinoLexerParser, String nombre_extension_lex, String nombre_extension_CUP, String nombreParser) throws IOException, Exception{
        /* CREA LEXER EN JAVA */
        String op[] = new String[3];
        op[0]= "-d"; // opción de dirección de destino
       
        op[1]=destinoLexerParser;
       
        //dirección donde se encuentra el archivo .jflex y nombre del archivo.jlex
        op[2] = origenLex + "/" + nombre_extension_lex;
        
        JFlex.Main.main(op);
       
        /* CREA PARSER EN JAVA */
        //String rutaRelativaCUP =  "/src/Lex_CUP/Parser.cup";
        String opciones[] = new String[5];
        opciones[0] = "-destdir";// opción de dirección de destino
        
        opciones[1] = destinoLexerParser;//"/src/Lexico_Parser"; // dirección de destino
        
        opciones[2] = "-parser";// opción de nombre de archivo
        
        opciones[3] = nombreParser;
        
        //dirección donde se encuentra el archivo .cup y nombre del archivo.cup
        opciones[4] = origenCUP + "/" + nombre_extension_CUP;
        java_cup.Main.main(opciones);
   }

}
