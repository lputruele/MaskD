package Interfaz.AuxiliarInterfaz;

import java.util.LinkedList;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ColaDinamica extends LinkedList implements Cola{
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private int ultimo;//Almacena el índice del último elemento de la cola
    
   
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public ColaDinamica(){
        super();
        ultimo=-1;
    }
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     -------------IMPLEMENTACIÓN DE MÉTODOS DE LA INTERFAZ Cola------------
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    
    /*
        SE REDEFINE EL MÉTODO add(Object objecto) DE "LinkedList" QUE IMPLEMENTA
        LA INTERFACE "Queue":
        SE REGISTRA EN LA COLA, EL ÍNDICE DEL ÚLTIMO ELEMENTO AGREGADO
    */
    public boolean add(Object objeto){
        if(!this.contains(objeto)){
            ultimo++;
            super.add(objeto);
        }
        return false;
    }
    
    
    /*
        SE REDEFINE EL MÉTODO remove() DE "LinkedList" QUE IMPLEMENTA
        LA INTERFACE "Queue":
        SE REGISTRA EN LA COLA, EL ÍNDICE DEL ÚLTIMO ELEMENTO QUE QUEDA LUEGO
        DE ELIMINAR EL PRIMER ELEMENTO.
    */
    public Object remove(){
        Object objeto = null;
        if(!this.isEmpty()){
            ultimo--;
            objeto = super.remove();
        }
        return objeto;
    }
    
    
    /*
       MÉTODO QUE OBTIENE EL ÚLTIMO ELEMENTO AGREGADO EN LA COLA 
    */
    public Object obtenerUltimo(){
        Object objeto = null;
        if(!this.isEmpty()){
            objeto = this.get(ultimo);
        }
        return objeto;
    }
    
}
