package Interfaz.Eventos.EventosUIModelo;

import AnalizadorModelo.AuxiliarModelo.Par;
import Interfaz.Eventos.EventosUIPropiedad.EventosPropiedad;
import Interfaz.AuxiliarInterfaz.ConfiguracionTexto;
import Interfaz.InterfazGrafica.GUIPrincipal;
import Interfaz.InterfazGrafica.UIAvisoResultadoMC;
import Interfaz.InterfazGrafica.UIModelo;
import Interfaz.InterfazGrafica.UIPropiedadDCTL;
import Interfaz.AuxiliarInterfaz.Cuaterna;
import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import javax.swing.text.BadLocationException;
import net.sf.javabdd.BDD;
import Formulas.FormulaElement; 
import Interfaz.AuxiliarInterfaz.ManipulacionListas;
import ModelChecker.BDDModel;
import ModelChecker.DctlMC;
import ModelChecker.VarInfo;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ActionListenerUIModelo implements ActionListener{
    
/*
   Una instancia de 'ActionListenerUIModelo' está asociada a una única
   instancia de UIModelo, GUIPrincipal, EventosModelo, EventosPropiedad y
   ManipulacionArchivos (definidos en la sección de atributos)
*/    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    
    
    private UIModelo uiModelo;
    private GUIPrincipal parent;
    private EventosModelo eventos_modelo;
    private EventosPropiedad eventos_propiedad;
    private ManipulacionArchivos manipulacionArchivos;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    
    
    public ActionListenerUIModelo(UIModelo uiModelo, GUIPrincipal parent){
        super();
        this.uiModelo = uiModelo;
        this.parent = parent;
        eventos_modelo = new EventosModelo(uiModelo);
        eventos_propiedad = new EventosPropiedad(uiModelo);
        manipulacionArchivos = new ManipulacionArchivos(uiModelo);
    }
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     IMPLEMENTACIÓN DEL MÉTODO DE LA INTERFAZ ActionListener PARA "UIModelo"
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        
        
        /*
          ----------------FUNCIONALIDADES DE LA PESTAÑA "Modelo"----------------
        */
        
        
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN EL BOTÓN "Analizar" DE LA
           PESTAÑA "Modelo" DE LA VENTANA SOBRE LA QUE SE ESPECIFICA EL MODELO.
        */
        if(e.getSource() == uiModelo.getButtonAnalizarSintaxis()){
            if(!uiModelo.getContenedorTextoModelo().getText().trim().equals("")){//Si el modelo no es vacío
                Cuaterna info_parser = null;
                try {
                    
                    /*
                       Se analiza sintáctica y semánticamente el modelo 
                    */    
                    info_parser = eventos_modelo.analizarModelo();  

                }
                catch (UnsupportedEncodingException ex) {
                    uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                    try {
                        ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                    }
                    catch (BadLocationException ex1) {
                    }
                } 
                catch (Exception ex) {
                    uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                    try {
                        ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                    }
                    catch (BadLocationException ex1) {
                    }
                }
                
                /*
                   Se almacena información obtenida del parsing 
                */
                uiModelo.setBDDInicializacion((BDD) info_parser.getPrimero());
                uiModelo.setBDDModelo((BDD) info_parser.getSegundo());
                uiModelo.setResultadoAnalisisModelo((String) info_parser.getTercero());
                uiModelo.setVbleDecl((List)info_parser.getCuarto());
                uiModelo.setBDDNormal((BDD) info_parser.getQuinto());
                
                if(!uiModelo.getListaPropiedad().isSelectionEmpty()){//Si previo a analizar la sintáxis y semántica del modelo, 
                                                                     //se agregan propiedades a la lista de la pestaña "Propiedad"
                                                                     //de la ventana sobre la que se especifica el modelo
                                                                     // y una propiedad está seleccionada
                    String propiedad = (String) uiModelo.getListaPropiedad().getSelectedValue();
                    try {  
                        
                        /*
                           Se analiza sintáctica y semánticamente la propiedad seleccionada.
                           De acuerdo al resultado del análisis, se habilita ó deshabilita
                           el botón que invoca al Model Checker para chequear la propiedad
                           seleccionada sobre el modelo
                        */
                        eventos_propiedad.habilitar_deshabilitar_chequear(propiedad);
                    }
                    catch (UnsupportedEncodingException ex) {
                        try {
                            ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                        } 
                        catch (BadLocationException ex1) {
                        
                        }
                    } 
                    catch (Exception ex) {
                        try {
                            ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                        }
                        catch (BadLocationException ex1) {
                        
                        }
                    }
                }
            }
            else{//Si el modelo es vacío
                
                /*
                   Se borra el texto (si hubiera) de la parte inferior de la 
                   pestaña "Modelo" de la ventana sobre la que se especifica 
                   el modelo
                */
                uiModelo.getContendorTextoMuestraResultado().setText("");
            }
        }
        
        
         /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Nuevo" DEL MENÚ 
          "Archivo" DE LA PESTAÑA "Modelo" DE LA VENTANA SOBRE LA QUE
          SE ESPECIFICA EL MODELO.
        */
        if(e.getSource() == uiModelo.getMenuItemNuevo()){
            UIModelo editor = new UIModelo(parent, false);
            editor.setVisible(true);
        }
        
        
         /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Abrir" DEL MENÚ 
          "Archivo" DE LA PESTAÑA "Modelo" DE LA VENTANA SOBRE LA QUE
          SE ESPECIFICA EL MODELO:
          SE ABREN ARCHIVOS .mod, ALMACENADOS EN EL DIRECTORIO SELECCIONADO POR
          EL USUARIO, CADA UNO EN DISTINTAS VENTANAS.
        */
        if(e.getSource() == uiModelo.getMenuItemAbrir()){
              try {
                  File[] ficheros = manipulacionArchivos.abrirArchivos(uiModelo);
                  UIModelo modelo =uiModelo;
                   /*Cada instancia de 'UIModelo' tiene asociado un archivo
                    seleccionado a abrir:
                      - Almacena ruta, nombre y extensión del archivo .
                      - Almacena como título de la ventana,la ruta, nombre y 
                        extensión del archivo
                      - Actualiza el formato de cada palabra del archivo,
                        (resalta palabras reservadas y comentarios)
                       
                      Todas las ventanas 'UIModelo' que se abran,
                      tienen el mismo "padre" GUIPrincipal
                  */
                  if(ficheros != null){//Si se abre al menos un archivo
                      for(int i=0;i<ficheros.length;i++){
                          if((i!=0)||(!modelo.getContenedorTextoModelo().getText().trim().equals(""))){
                              modelo=new UIModelo(parent,false);
                          }
                          modelo.getContenedorTextoModelo().setText(manipulacionArchivos.obtenerContenidoArchivo(ficheros[i]));
                          modelo.setRutaArchivoActual(ficheros[i].getAbsolutePath());
                          modelo.setTitle(ficheros[i].toString());
                          ConfiguracionTexto.actualizarColoreoPalabrasReservadas(0,modelo.getContenedorTextoModelo().getText().length(), modelo.getContenedorTextoModelo());// Da formato a todo el texto, con formato de palabra reservada cada vez que se encuentre una de ellas
                          modelo.setVisible(true);
                          modelo.getContenedorTextoModelo().setCaretPosition(0); 
                      }
                  }
              } 
              catch (IOException ex) {
              }
              catch (BadLocationException ex) {
              }
        }
        
        
         /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Guardar como" DEL MENÚ 
           "Archivo" DE LA PESTAÑA "Modelo":
           SE CREA UN ARCHIVO .mod, EN EL DIRECTORIO SELECCIONADO POR EL 
           USUARIO, Y SE ALMACENA EN EL ARCHIVO CREADO, EL MODELO.
        */
        if(e.getSource() == uiModelo.getMenuItemGuardarComo()){
            try {
                if(!uiModelo.getContenedorTextoModelo().getText().equals("")){
                    Par par = manipulacionArchivos.guardarComo(uiModelo.getContenedorTextoModelo().getText(), "mod");
                    uiModelo.setRutaArchivoActual((String) par.getPrimero());
                    uiModelo.setTitle((String) par.getSegundo());  
                    uiModelo.setEsModeloEditado(false);
                }
            }
            catch (IOException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
        }
        
        
        
         /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Guardar" DEL MENÚ "Archivo" 
           DE LA PESTAÑA "Modelo"
       */
        if(e.getSource() == uiModelo.getMenuItemGuardar()){
            try {
                manipulacionArchivos.guardar(uiModelo.getRutaArchivoActual(), uiModelo.getContenedorTextoModelo().getText(), "mod");
            } catch (IOException ex) {
                Logger.getLogger(ActionListenerUIModelo.class.getName()).log(Level.SEVERE, null, ex);
            }
          
        }
        
        
        
        /*
         MÉTODO QUE SE INVOCA AL HACER CLIC EN "Copiar" DEL MENÚ "Editar" DE
         LA PESTAÑA "Modelo"
        */
        if(e.getSource() == uiModelo.getMenuItemCopiar()){
            uiModelo.getContenedorTextoModelo().copy();
        }
        
        
          /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Pegar" DEL MENÚ "Editar" DE
           LA PESTAÑA "Modelo"
            
        */
        if(e.getSource() == uiModelo.getMenuItemPegar()){
            try {
                eventos_modelo.pegar();
            }
            catch (BadLocationException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Cortar" DEL MENÚ "Editar" DE
           LA PESTAÑA "Modelo"
              
        */
        if(e.getSource() == uiModelo.getMenuItemCortar()){
            try {
                eventos_modelo.cortar();
            }
            catch (BadLocationException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
        }
        
  
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Ver DOT" DEL MENÚ "Ver" DE LA
           PESTAÑA "Modelo":
           SE MUESTRA EN LA VENTANA, DEBAJO DE LA ESPECIFICACIÓN DEL MODELO, 
           LOS .dot DE LOS ARCHIVOS CREADOS
       */
        if(e.getSource() == uiModelo.getMenuItemDOT()){
            try {
                eventos_modelo.verDOT();
            } 
            catch (IOException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
            catch (BadLocationException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Ver BDD" DEL MENÚ "Ver" DE LA
           PESTAÑA "Modelo":
           SE MUESTRAN LOS BDD's DEL MODELO (BDD DE LA INICIALIZACIÓN Y BDD DEL
           MODELO)
        */
        if(e.getSource() == uiModelo.getMenuItemBDD()){
            try {
                eventos_modelo.verBDD();
            }
            catch (IOException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
            catch (BadLocationException ex) {
                uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                try {
                    ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                }
                catch (BadLocationException ex1) {
                }
            }
        }
        
        
        /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN MENÚ "Maximizar" DE LA PESTAÑA 
          "Modelo"
        */
        if(e.getSource() == uiModelo.getMenuItemMaximizar()){
            uiModelo.setSize(uiModelo.getToolkit().getScreenSize()); 
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN EL MENÚ "Salir" DE LA PESTAÑA
           "Modelo". SE ELIMINA LA VENTANA UIModelo
        */
        if(e.getSource() == uiModelo.getMenuItemSalir()){
            eventos_modelo.salir();
        }


        
        
        /*
           -------------FUNCIONALIDADES DE LA PESTAÑA "Propiedad"--------------
        */
        
        
        
        
        if(e.getSource() == uiModelo.getButtonChequear()){
            String resultado="";
            String propiedadSeleccionada = (String) (uiModelo.getListaPropiedad().getSelectedValue());
            propiedadSeleccionada = propiedadSeleccionada.replaceAll("<html><font color=gray>", "");
            propiedadSeleccionada = propiedadSeleccionada.replaceAll("<html><font color=black>", "");
            propiedadSeleccionada = propiedadSeleccionada.replaceAll("</font></html>", "");
            FormulaElement vble = uiModelo.getFormula();
            BDD bddInicializacion = uiModelo.getBDDInicializacion();
            BDD bddModelo = uiModelo.getBDDModelo();
            BDD bddNormal = uiModelo.getBDDNormal();
            
            List VbleDecl = uiModelo.getVbleDecl();
            
            BDDModel bddModel = new BDDModel(bddModelo,bddInicializacion, bddNormal);
            for(int i=0; i<VbleDecl.size(); i++){
                bddModel.addVar((String)VbleDecl.get(i), VarInfo.Type.BOOL);
            }
            
            boolean resultadoBooleano=true;
            resultadoBooleano = DctlMC.mc_algorithm(vble, bddModel);
            
            if (resultadoBooleano){
                resultado="La propiedad es TRUE en el modelo";
            }else{
                resultado="La propiedad es FALSE en el modelo";
            }
            UIAvisoResultadoMC uiAvisoResultadoMC = new UIAvisoResultadoMC(uiModelo,true);               
            uiAvisoResultadoMC.setResultado(resultado);
            uiAvisoResultadoMC.setVisible(true);
            
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Nueva" DEL MENÚ "Editar lista"
           DE LA PESTAÑA "Propiedad":
           SE AGREGA UN PROPIEDAD, A LA LISTA DE PROPIEDADES
        */
        if(e.getSource() == uiModelo.getMenuItemNuevaPropiedad()){
            UIPropiedadDCTL ui_propiedad = new UIPropiedadDCTL(uiModelo,true,e);
            ui_propiedad.setVisible(true);
        }
        
              
        /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Abrir" DEL MENÚ "Editar lista" 
          DE LA PESTAÑA "Propiedad".   
        */
        if(e.getSource() == uiModelo.getMenuItemAbrirPropiedad()){
            try {
                eventos_propiedad.abrirPropiedades();
            } catch (UnsupportedEncodingException ex) {
                
            } catch (Exception ex) {
               
            }
        }
        

        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Eliminar" DEL MENÚ 
           "Editar lista" DE LA PESTAÑA "Propiedad".
        */
        if(e.getSource() == uiModelo.getMenuItemEliminarPropiedad()){
            eventos_propiedad.eliminarPropiedad();
        }
        
        
        /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Vaciar" DEL MENÚ "Editar lista"
          DE LA PESTAÑA "Propiedad".
        */
        if(e.getSource() == uiModelo.getMenuItemVaciarLista()){
            eventos_propiedad.vaciarLista();
        }
        
        
        /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Editar" DEL MENÚ "Editar lista"
          DE LA PESTAÑA "Propiedad".
        */
        if(e.getSource() == uiModelo.getMenuItemEditarPropiedad()){
            if(!uiModelo.getListaPropiedad().isSelectionEmpty()){                
                UIPropiedadDCTL ui_propiedad = new UIPropiedadDCTL(uiModelo,true,e);
                ui_propiedad.setVisible(true);
            }
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Editar" DEL MENÚ QUE SE 
           DESPLIEGA AL HACER CLIC DERECHO EN UNA PROPIEDAD SELECCIONADA.
        */
        if(e.getSource() == uiModelo.getMenuItemPopupEditar()){
            if(!uiModelo.getListaPropiedad().isSelectionEmpty()){   
                UIPropiedadDCTL ui_propiedad = new UIPropiedadDCTL(uiModelo,true,e);
                ui_propiedad.setVisible(true);
            }
        }
        
        
         /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Guardar" DEL MENÚ 
           "Editar lista" DE LA PESTAÑA "Propiedad".
        */
        if((e.getSource() == uiModelo.getMenuItemGuardarPropiedad())||(e.getSource() == uiModelo.getMenuItemPopupGuardar())){
            
            if(!uiModelo.getListaPropiedad().isSelectionEmpty()){
                try {
                    String propiedad = ((String)uiModelo.getListaPropiedad().getSelectedValue()).trim();
                    if(!(propiedad.equals(""))){
                        Par par=new Par("","");
                        propiedad=propiedad.replaceAll("<html><font color=gray>", "<html><font color=black>");
                        par = manipulacionArchivos.guardarComo(propiedad,"dCTL");
                        if(!((String)par.getPrimero()).equals("")){
                            propiedad = propiedad.replaceAll("<html><font color=gray>", "");
                            propiedad = propiedad.replaceAll("<html><font color=black>", "");
                            propiedad = propiedad.replaceAll("</font></html>", "");
                            if(!ManipulacionListas.contiene(uiModelo.getPropiedadesGuardadas(),propiedad)){
                                uiModelo.getPropiedadesGuardadas().add(propiedad);
                            }
                            if(uiModelo.getLista().contains("<html><font color=gray>"+propiedad+"</font></html>")){
                                uiModelo.getLista().set(uiModelo.getLista().indexOf("<html><font color=gray>"+propiedad+"</font></html>"), "<html><font color=black>"+propiedad+"</font></html>");
                            }
                            Par ruta_propiedad = ManipulacionListas.buscar_listaRutaPropiedad(uiModelo.getLista_rutaPropiedad(), propiedad);
                            if(ruta_propiedad.getSegundo().equals("")){
                                uiModelo.setLista_rutaPropiedad(ManipulacionListas.eliminar_rutaPropiedad(uiModelo.getLista_rutaPropiedad(),ruta_propiedad));
                                par.setPrimero(propiedad);
                                uiModelo.getLista_rutaPropiedad().add(par);
                            }
                        }
                    }
                }
                catch (IOException ex) {
                    uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
                    try {
                        ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
                    }
                    catch (BadLocationException ex1) {
                    }
                }
            }
        }        
                

        
        
        /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Copiar" DEL MENÚ "Editar lista"
          DE LA PESTAÑA "Propiedad"
        */
        if(e.getSource() == uiModelo.getMenuItemCopiarPropiedad()){
            eventos_propiedad.copiarPropiedad();
        }               
                
        
        /*
          MÉTODO QUE SE INVOCA AL HACER CLIC EN "Copiar" DEL MENÚ QUE SE 
          DESPLIEGA AL HACER CLIC DERECHO EN UNA PROPIEDAD SELECCIONADA
        */
        if(e.getSource() == uiModelo.getMenuItemPopupCopiarPropiedad()){
            eventos_propiedad.copiarPropiedad();
        }

    }
    

    

    
}
