package Interfaz.Eventos.EventosUIModelo;

import Interfaz.Eventos.EventosUIPropiedad.EventosPropiedad;
import Interfaz.InterfazGrafica.UIModelo;
import java.io.UnsupportedEncodingException;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ListSelectionListenerUIModelo implements ListSelectionListener {

/*
   Una instancia de 'ListSelectionListenerUIModelo' está asociada a una única 
   instancia de UIModelo y EventosPropiedad (definidos en la sección de 
   atributos)
*/ 
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private UIModelo uiModelo;
    private EventosPropiedad eventos_propiedad;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public ListSelectionListenerUIModelo(UIModelo uiModelo){
        super();
        this.uiModelo = uiModelo;
        eventos_propiedad = new EventosPropiedad(uiModelo);
    }
    
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     IMPLEMENTACIÓN DE MÉTODOS DE LA INTERFAZ ListSelectionListener 
     PARA "UIModelo"
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    
    
    /*
        MÉTODO QUE SE INVOCA LUEGO DE REALIZAR CAMBIOS SOBRE LA LISTA DE
        PROPIEDADES, AGREGAR, EDITAR, ELIMINAR Ó SELECCIONAR PROPIEDADES.
    */
    @Override
    public void valueChanged(ListSelectionEvent lse) {
        try {
            if(!lse.getValueIsAdjusting()){//Si el evento es seleccionar una propiedad
                                           //(Método getValueIsAdjusting():Devuelve si es o no es 
                                           //parte de una serie de múltiples eventos, donde todavía
                                           //se están haciendo cambios)
                eventos_propiedad.actualizarLista();
            }
        } 
        catch (UnsupportedEncodingException ex) {
        } 
        catch (Exception ex) {
        }
    }
    
}
