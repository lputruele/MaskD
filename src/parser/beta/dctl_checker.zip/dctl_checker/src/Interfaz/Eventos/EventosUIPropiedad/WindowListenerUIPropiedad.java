package Interfaz.Eventos.EventosUIPropiedad;


import Interfaz.InterfazGrafica.UIModelo;
import Interfaz.InterfazGrafica.UIPropiedadDCTL;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class WindowListenerUIPropiedad implements WindowListener {

/*
   Una instancia de 'WindowListenerUIPropiedad' está asociada a una única instancia de 
   UIModelo y UIPropiedadDCTL (definidos en la sección de atributos)
*/ 
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private UIModelo uiModelo;
    private UIPropiedadDCTL uiPropiedad;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public WindowListenerUIPropiedad(UIModelo uiModelo, UIPropiedadDCTL uiPropiedad){
        super();   
        this.uiModelo = uiModelo;
        this.uiPropiedad = uiPropiedad;
    }
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     IMPLEMENTACIÓN DE MÉTODOS DE LA INTERFAZ WindowListener PARA 
     "UIPropiedadDCTL"
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    @Override
    public void windowOpened(WindowEvent we) {
        
    }

    
    /*
       MÉTODO QUE SE INVOCA AL HACER CLIC EN EL BOTÓN SUPERIOR IZQUIERDO
       (LA CRUZ) DE LA VENTANA SOBRE LA QUE SE ESCRIBEN PROPIEDADES.
    */
    @Override
    public void windowClosing(WindowEvent we) {
       uiModelo.setPropiedadAPegar("");
       uiPropiedad.dispose();
    }

    @Override
    public void windowClosed(WindowEvent we) {
       
    }

    @Override
    public void windowIconified(WindowEvent we) {
        
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
       
    }

    @Override
    public void windowActivated(WindowEvent we) {
    }

    @Override
    public void windowDeactivated(WindowEvent we) {
       
    }
    
}
