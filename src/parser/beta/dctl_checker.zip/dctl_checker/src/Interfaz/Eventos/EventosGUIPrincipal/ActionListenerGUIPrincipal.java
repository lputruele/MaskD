package Interfaz.Eventos.EventosGUIPrincipal;

import Interfaz.AuxiliarInterfaz.ConfiguracionTexto;
import Interfaz.InterfazGrafica.GUIPrincipal;
import Interfaz.InterfazGrafica.UIModelo;
import Interfaz.AuxiliarInterfaz.GeneracionLexerParser;
import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.text.BadLocationException;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ActionListenerGUIPrincipal implements ActionListener{
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    
    private GUIPrincipal guiPrincipal;
    private ManipulacionArchivos manipulacionArchivos;
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    
    public ActionListenerGUIPrincipal(GUIPrincipal guiPrincipal){
        super();
        this.guiPrincipal = guiPrincipal;
        manipulacionArchivos = new ManipulacionArchivos(guiPrincipal);
    }
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     IMPLEMENTACIÓN DEL MÉTODO DE LA INTERFAZ ActionListener PARA "GUIPrincipal"
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    @Override
    public void actionPerformed(ActionEvent ev) {

        /* 
          MÉTODO QUE ABRE ARCHIVOS .mod EN VENTANAS "UIModelo", SELECCIONADOS
          POR EL USUARIO. CADA VENTANA "UIModelo" CARGA EL CONTENIDO DE UN
          ARCHIVO SELECCIONADO PARA ABRIR.
       */
        if(ev.getSource() == guiPrincipal.getMenuItemAbrirModelo()){  
             generarLexCUP_modelo_propiedad();
              UIModelo modelo = new UIModelo(guiPrincipal,false);
              try {
                  File[] ficheros = manipulacionArchivos.abrirArchivos(modelo);
                  /*Cada instancia de 'UIModelo' tiene asociado un archivo
                    seleccionado a abrir:
                      - Almacena ruta, nombre y extensión del archivo .
                      - Almacena como título de la ventana,la ruta, nombre y 
                        extensión del archivo
                      - Actualiza el formato de cada palabra del archivo,
                        (resalta palabras reservadas y comentarios)
                       
                      Todas las ventanas 'UIModelo' que se abran,
                      tienen el mismo "padre" GUIPrincipal
                  */
                  if(ficheros!=null){
                      for(int i=0;i<ficheros.length;i++){
                          if((i!=0)||(!modelo.getContenedorTextoModelo().getText().trim().equals(""))){
                              modelo=new UIModelo(guiPrincipal,false);
                          }
                          modelo.getContenedorTextoModelo().setText(manipulacionArchivos.obtenerContenidoArchivo(ficheros[i])); 
                          modelo.setRutaArchivoActual(ficheros[i].getAbsolutePath());
                          modelo.setTitle(ficheros[i].toString());
                          ConfiguracionTexto.actualizarColoreoPalabrasReservadas(0,modelo.getContenedorTextoModelo().getText().length(), modelo.getContenedorTextoModelo());// Da formato a todo el texto, con formato de palabra reservada cada vez que se encuentre una de ellas
                          modelo.setVisible(true);
                          modelo.getContenedorTextoModelo().setCaretPosition(0); 
                      }
                  }
              } 
              catch (IOException ex) {
              }
              catch (BadLocationException ex) {
              }       
          }
        

        /* 
           MÉTODO QUE ABRE UNA VENTANA 'UIModelo'. LA VENTANA SE ENCUENTRA
           SIN TEXTO, CON LA POSIBILIDAD DE ESCRIBIR Ó ABRIR UN MODELO.
       */
        if(ev.getSource() == guiPrincipal.getMenuItemNuevoModelo()){                  
              generarLexCUP_modelo_propiedad();
              UIModelo modelo = new UIModelo(guiPrincipal,false);
              modelo.setVisible(true);
          }
    }
    
    
    /*
       MÉTODO QUE GENERA DOS LEXER Y DOS PARSER DE EXTENSIÓN .JAVA. 
       UN LEXER Y PARSER QUE PERMITR ANALIZAR LÉXICA, SINTÁCTICA Y 
       SEMÁNTICAMENTE MODELOS, Y OTRO LEXER Y PARSER QUE PERMITE ANALIZAR 
       LÉXICA, SINTÁCTICA Y SEMÁNTICAMENTE LAS PROPIEDADES dCTL.
       LA GENERACIÓN AUTOMÁTICA DE LEXER Y PARSER PARA MODELOS Y PROPIEDADES,
       SE REALIZA A PARTIR DE LOS ARCHIVOS LexerModelo.jlex y ParserModelo.cup, 
       y Parser.jlex y Scanner.jflex RESPECTIVAMENTE.
    */
    private void generarLexCUP_modelo_propiedad(){
        try{
            String separador = System.getProperty("file.separator");
            String rutaLex_modelo = manipulacionArchivos.buscarRuta(separador+"AnalizadorModelo"+separador+"LexCup");
            String rutaCUP_modelo = rutaLex_modelo;
            String rutaLexerParser_modelo = manipulacionArchivos.buscarRuta(separador + "AnalizadorModelo"+separador+"LexerParser");
            GeneracionLexerParser.crearArchivo_lexer_parser(rutaLex_modelo,rutaCUP_modelo,rutaLexerParser_modelo, "LexerModelo.jlex","ParserModelo.cup","ParserModelo");//Se crea Lexer.java y Parser.java para modelos
            String rutaLex_propiedades = manipulacionArchivos.buscarRuta(separador+"AnalizadorPropiedades"+separador+"LexCup");
            String rutaCUP_propiedades = rutaLex_propiedades;
            String rutaLexerParser_propiedades = manipulacionArchivos.buscarRuta(separador+"AnalizadorPropiedades"+separador+"LexerParser");
            GeneracionLexerParser.crearArchivo_lexer_parser(rutaLex_propiedades,rutaCUP_propiedades, rutaLexerParser_propiedades,"Scanner.jflex","Parser.cup","Parser_dCTL");//Se crea Lexer.java y Parser.java para propiedades
        }
        catch (Exception e) {

        }
    }
}
