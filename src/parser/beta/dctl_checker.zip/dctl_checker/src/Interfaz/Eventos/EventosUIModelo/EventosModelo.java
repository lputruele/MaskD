package Interfaz.Eventos.EventosUIModelo;

import Interfaz.AuxiliarInterfaz.ConfiguracionTexto;
import Interfaz.InterfazGrafica.UIAvisoCerrarUIModelo;
import Interfaz.InterfazGrafica.UIModelo;
import AnalizadorModelo.LexerParser.LexerModelo;
import AnalizadorModelo.LexerParser.ParserModelo;
import Interfaz.AuxiliarInterfaz.ColaDinamica;
import Interfaz.AuxiliarInterfaz.Cuaterna;
import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import AnalizadorModelo.AuxiliarModelo.Par;
import Interfaz.AuxiliarInterfaz.Terna;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.List;
import javax.swing.text.BadLocationException;
import net.sf.javabdd.BDD;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class EventosModelo {

/*
   Una instancia de 'EventosModelo' está asociada a una única instancia de 
   UIModelo y ManipulacionArchivos (definidos en la sección de atributos)
*/ 

    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private UIModelo uiModelo;
    private ManipulacionArchivos manipulacionArchivos;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public EventosModelo(UIModelo uiModelo){
        this.uiModelo = uiModelo;
        manipulacionArchivos = new ManipulacionArchivos(uiModelo);
        
    }
    
    
    /*
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
       ---------------------------MÉTODOS PÚBLICOS----------------------------
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
    */
    
    
    
  

    /*
           SE REALIZA LA CONVERSIÓN DEL TEXTO QUE DEFINE AL MODELO, EN UN 
           InputStream. EL MISMO SE PASA COMO PARÁMETRO AL ANALIZADOR LÉXICO, Y
           ESTE ÚLTIMO ES PARÁMETRO DEL ANALIZADOR SINTÁCTICO.
           SE PARSEA EL MODELO OBTENIENDO INFORMACIÓN DE ERRORES SINTÁCTICOS Y 
           SEMÁNTICOS SI LOS HUBIERA. EN CASO EN QUE EL MODELO NO TENGA ERRORES
           SINTÁCTICOS Y SEMÁNTICOS, SE OBTIENEN LOS BDD'S ASOCIADOS AL MODELO
           (BDD DE LA INICIALIZACIÓN DE LMODELO Y BDD DEL MODELO) 
    */
    public Cuaterna analizarModelo() throws UnsupportedEncodingException, Exception{
        String texto = uiModelo.getContenedorTextoModelo().getText();
        String resultadoAnalisisModelo="";
        BDD bddInicializacion=null;
        BDD bddNormal=null;
        BDD bddModelo=null;
        InputStream is=null;
        is = new ByteArrayInputStream(texto.getBytes("UTF-8"));
        LexerModelo lexerModelo = new LexerModelo(is);
        ParserModelo parserModelo = new ParserModelo (lexerModelo);
        
        /* Se realiza parsing para analizar sintáctica y semánticamente 
           el modelo, y para construir los BDD's que lo representan.
           Durante el análisis sintáctico y semántico se registran en una 
           lista, los errores sintáctico y semánticos detectados.
           El resultado del análisis, ya sea exitoso ó no, se muestra en la
           parte inferior de la ventana sobre la que está escrito el modelo
        */
        parserModelo.parse();
        resultadoAnalisisModelo = parserModelo.obtenerResultado();
        uiModelo.getContendorTextoMuestraResultado().setText(resultadoAnalisisModelo);
        ConfiguracionTexto.darFormatoDeTexto(0,resultadoAnalisisModelo.length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
        uiModelo.getContendorTextoMuestraResultado().setCaretPosition(0);
        bddInicializacion = parserModelo.obtenerBDD_inicializacion();
        bddNormal= parserModelo.obtenerBDD_normal();
        bddModelo = parserModelo.obtenerBDD_modelo();
        uiModelo.getMenuItemDOT().setEnabled(true);
        uiModelo.getMenuItemBDD().setEnabled(true);
        String nombreModelo="";
        if((bddInicializacion!=null)&&(bddModelo!=null)&&(bddNormal!=null)){//Si es modelo que soporta la construcción de BDD
            String ruta_nombre_extension_dotInic="";
            String ruta_nombre_extension_dotNorm="";
            String ruta_nombre_extension_dotModelo="";
            String ruta_nombre_extension_bddInic="";
            String ruta_nombre_extension_bddNorm="";
            String ruta_nombre_extension_bddModelo="";
            ManipulacionArchivos manipulacionArchivos = new ManipulacionArchivos();
            String separador = System.getProperty("file.separator");
            String rutaDOT = manipulacionArchivos.buscarRuta(separador+"DOT"+separador);
            String rutaBDD = manipulacionArchivos.buscarRuta(separador+"Graficos_BDDs"+separador);
            if(!uiModelo.getRutaArchivoActual().equals("")&&(!uiModelo.getEsModeloEditado())){  // Si es modelo guardado          
                               
                String ruta=uiModelo.getRutaArchivoActual().replaceAll(".mod", "");
                int indice = ruta.lastIndexOf(separador);
                indice++;
                nombreModelo=ruta.substring(indice);
                rutaDOT = rutaDOT + nombreModelo;
                rutaBDD = rutaBDD + nombreModelo;                                  
            }
            else{
                rutaDOT = rutaDOT + "DOT";
                rutaBDD = rutaBDD + "BDD";
            } 
            ruta_nombre_extension_dotInic=rutaDOT+"_inicModelo.dot";
            ruta_nombre_extension_dotNorm=rutaDOT+"_normModelo.dot";
            ruta_nombre_extension_dotModelo=rutaDOT+"_modelo.dot";         
            ruta_nombre_extension_bddInic=rutaBDD+"_inicModelo.pdf";
            ruta_nombre_extension_bddNorm=rutaBDD+"_normModelo.pdf";
            ruta_nombre_extension_bddModelo=rutaBDD+"_modelo.pdf";    
            /*
               Se crean los .dot y .bdd asociados al modelo, con los
               nombres especificados anteriormente.
            */
            manipulacionArchivos.escribirEnArchivo(new File(ruta_nombre_extension_dotInic),obtenerDOT(bddInicializacion,parserModelo.getVariablesDeclaradas()));
            manipulacionArchivos.escribirEnArchivo(new File(ruta_nombre_extension_dotNorm),obtenerDOT(bddNormal,parserModelo.getVariablesDeclaradas()));
            manipulacionArchivos.escribirEnArchivo(new File(ruta_nombre_extension_dotModelo),obtenerDOT(bddModelo,parserModelo.getVariablesDeclaradas()));
            manipulacionArchivos.crearGraficoBDD(ruta_nombre_extension_dotInic, ruta_nombre_extension_bddInic);
            manipulacionArchivos.crearGraficoBDD(ruta_nombre_extension_dotNorm, ruta_nombre_extension_bddNorm);
            manipulacionArchivos.crearGraficoBDD(ruta_nombre_extension_dotModelo,ruta_nombre_extension_bddModelo);
        }
        parserModelo.vaciarListaErrores();//Se vacía la lista de errores
        return new Cuaterna(bddInicializacion,bddModelo,resultadoAnalisisModelo,parserModelo.getVariablesDeclaradas(),bddNormal);
    }
    
    
        
    /*
        MÉTODO QUE PEGA TEXTO COPIADO Ó CORTADO, EN EL MODELO.
          - SE DA EL FORMATO AL NUEVO MODELO RESULTANTE
          - SE ACTUALIZA EL NÚMERO DE LÍNEAS DEL NUEVO MODELO RESULTANTE.
            SI EL PEGAR EL TEXTO COPIADO Ó CORTADO, NO IMPLICA TENER UNA NUEVA 
            LÍNEA DE TEXTO EN EL MODELO, LA ACTUALIZACIÓN NO PRODUCE CAMBIOS 
    */
    public void pegar() throws BadLocationException{
       
        uiModelo.getContenedorTextoModelo().paste();
        int posicion = uiModelo.getContenedorTextoModelo().getCaretPosition();
        ConfiguracionTexto.actualizarColoreoPalabrasReservadas(0,uiModelo.getContenedorTextoModelo().getText().length(),uiModelo.getContenedorTextoModelo());
        uiModelo.getContenedorTextoModelo().setCaretPosition(posicion);
    }
    
    
     /*
         
         MÉTODO QUE CORTA TEXTO SELECCIONADO DEL MODELO.
         LUEGO DE CORTAR EL TEXTO:
             - SE DA EL FORMATO ADECUADO AL NUEVO MODELO RESULTANTE
             - SE ACTUALIZA EL NÚMERO DE LÍNEAS DEL NUEVO MODELO RESULTANTE     
    */
    public void cortar() throws BadLocationException{
        
        uiModelo.getContenedorTextoModelo().cut();
        ConfiguracionTexto.actualizarColoreoPalabrasReservadas(0,uiModelo.getContenedorTextoModelo().getText().length(),uiModelo.getContenedorTextoModelo());
    }
    
 
    /*
       SE MUESTRA EN LA PARTE INFERIOR DE LA VENTANA SOBRE LA QUE ESTÁ
       ESCRITO EL MODELO, EL CONTENIDO DE LOS ARCHIVOS .dot ASOCIADOS AL MODELO.
    */
    public void verDOT() throws IOException, BadLocationException{
        String separador = System.getProperty("file.separator");
        String rutaDOT = manipulacionArchivos.buscarRuta(separador+"DOT"+separador);
        String rutaDOTInicModelo="";
        String rutaDOTNorm="";
        String rutaDOTModelo="";
        if((uiModelo.getBDDInicializacion()!=null)&&(uiModelo.getBDDModelo()!=null)&&(uiModelo.getBDDNormal()!=null)){//Si es modelo que soporta BDD's
            File archivoInic=null;
            File archivoModelo=null;
            File archivoNorm=null;
            if(uiModelo.getRutaArchivoActual().equals("")||(uiModelo.getEsModeloEditado())){//Si el modelo asociado a los DOT's a mostrar,                                                                                     //no fue guardado, ó fue guardado y después editado sin 
                                                                                //analizar su sintáxis y semántica luego de la edición
                /*
                   Se referencia a los archivos DOT's creados, asociados al modelo 
                */        
                rutaDOTInicModelo = rutaDOT + "DOT_inicModelo.dot";
                rutaDOTNorm = rutaDOT + "DOT_normModelo.dot";                    
                rutaDOTModelo = rutaDOT + "DOT_modelo.dot";    
            }
            else{//Si el modelo asociado a los DOT's a mostrar, fue guardado ó
                 //no fue guardado pero se analizó su sintáxis y semántica sin editar
                 //posteriormente el modelo       
                /*
                   Se referencia a los archivos DOT's creados, asociados al modelo 
                */
                String ruta=uiModelo.getRutaArchivoActual().replaceAll(".mod", "");
                int indice = ruta.lastIndexOf(separador);
                indice++;
                String nombreModelo=ruta.substring(indice);
                rutaDOTInicModelo = rutaDOT +  nombreModelo + "_inicModelo.dot";
                rutaDOTNorm = rutaDOT +  nombreModelo + "_normModelo.dot";                    
                rutaDOTModelo = rutaDOT + nombreModelo + "_modelo.dot";
            }    
            archivoInic = new File(rutaDOTInicModelo);
            archivoNorm = new File(rutaDOTNorm);
            archivoModelo = new File(rutaDOTModelo);
            /*
               Se almacena en la parte inferior de la ventana sobre la que se especifica el modelo,
               el contenido de los arhcivos DOT's referenciados, asociados al modelo
            */
            String DOT_inic = manipulacionArchivos.obtenerContenidoArchivo(archivoInic);
            String DOT_modelo = manipulacionArchivos.obtenerContenidoArchivo(archivoModelo);
            String DOT_norm = manipulacionArchivos.obtenerContenidoArchivo(archivoNorm);
            uiModelo.getContendorTextoMuestraResultado().setText("DOT del modelo:\n\n" + DOT_modelo);
            ConfiguracionTexto.darFormatoDeTexto(0, ("DOT del modelo:\n\n" + DOT_modelo).length(), ConfiguracionTexto.getFormatoNegrita(),uiModelo.getContendorTextoMuestraResultado());
            ConfiguracionTexto.agregarTexto(("DOT del modelo:\n\n" + DOT_modelo).length(),"\n\n\nDOT de la inicialización del modelo:\n\n" + DOT_inic,ConfiguracionTexto.getFormatoNegrita(),uiModelo.getContendorTextoMuestraResultado());
            ConfiguracionTexto.agregarTexto(("DOT del modelo:\n\n" + DOT_modelo).length(),"\n\n\nDOT de la normalización del modelo:\n\n" + DOT_norm,ConfiguracionTexto.getFormatoNegrita(),uiModelo.getContendorTextoMuestraResultado());
            uiModelo.getContendorTextoMuestraResultado().setCaretPosition(0);
        }
        else{//Si no es modelo que soporta BDD's
            uiModelo.getContendorTextoMuestraResultado().setText("DOT de la inicialización, normalización y/o del modelo, no soportado");
            ConfiguracionTexto.darFormatoDeTexto(0,("DOT de la inicialización, normalización y/o del modelo, no soportado").length(),ConfiguracionTexto.getFormatoNegrita(),uiModelo.getContendorTextoMuestraResultado());
        }
    }
    
    
    /*
       SE MUESTRA EN LA PARTE INFERIOR DE LA VENTANA SOBRE LA QUE ESTÁ
       ESCRITO EL MODELO, EL CONTENIDO DE LOS ARCHIVOS .bdd ASOCIADOS AL MODELO. 
    */
    public void verBDD() throws IOException, BadLocationException{
        String separador = System.getProperty("file.separator");
        String rutaBDD = manipulacionArchivos.buscarRuta(separador+"Graficos_BDDs"+separador);    
        String rutaBDDInicModelo="";
        String rutaBDDNorm="";
        String rutaBDDModelo="";
        if((uiModelo.getBDDInicializacion()!=null)&&(uiModelo.getBDDModelo()!=null)&&(uiModelo.getBDDNormal()!=null)){//Si es modelo que soporta BDD's 
            if(uiModelo.getRutaArchivoActual().equals("")||(uiModelo.getEsModeloEditado())){//Si el modelo asociado a los BDD's a mostrar,                                                                                 //analizar su sintáxis y semántica luego de la edición
                rutaBDDInicModelo = rutaBDD + "BDD_inicModelo.pdf";
                rutaBDDNorm = rutaBDD + "BDD_normModelo.pdf";                    
                rutaBDDModelo = rutaBDD + "BDD_modelo.pdf";
            }
            else{//Si el modelo asociado a los DOT's a mostrar, fue guardado ó
                 //no fue guardado pero se analizó su sintáxis y semántica sin editar
                 //posteriormente el modelo                    
                /*
                  Se referencia a los archivos DOT's creados, asociados al modelo 
                */
                String ruta=uiModelo.getRutaArchivoActual().replaceAll(".mod", "");
                int indice = ruta.lastIndexOf(separador);
                indice++;
                String nombreModelo=ruta.substring(indice);  
                rutaBDDInicModelo = rutaBDD +  nombreModelo + "_inicModelo.pdf";
                rutaBDDNorm = rutaBDD +  nombreModelo + "_normModelo.pdf";                    
                rutaBDDModelo = rutaBDD + nombreModelo + "_modelo.pdf";
            }
            /*
               Se referencia a los archivos BDD's creados, asociados al modelo 
            */
            manipulacionArchivos.mostrarArchivoBDD(rutaBDDInicModelo);
            manipulacionArchivos.mostrarArchivoBDD(rutaBDDNorm);
            manipulacionArchivos.mostrarArchivoBDD(rutaBDDModelo);
        }
        else{//Si no es modelo que soporta BDD's
            uiModelo.getContendorTextoMuestraResultado().setText("BDD de la inicialización, normalización y/o del modelo, no soportado");
            ConfiguracionTexto.darFormatoDeTexto(0,("BDD de la inicialización, normalización y/o del modelo, no soportado").length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
        }
    }
    
    
    /*
       MÉTODO ENCARGADO DE:
         - ELIMINAR LA VENTANA SOBRE LA QUE ESTÁ ESCRITO EL MODELO, SI NO HAY
           PROPIEDADES ESCRITAS SOBRE EL MODELO, Ó TODAS LAS PROPIEDADES 
           ESCRITAS SOBRE EL MODELO FUERON GUARDADAS
         - VISUALIZAR UNA VENTANA QUE INFORMA SOBRE LA SITUACIÓN DE TENER
           PROPIEDADES SIN GUARDAR, SI EXISTE AL MENOS UNA PROPIEDAD QUE NO
           FUE GUARDADA.
    */
    public void salir(){
        if(uiModelo.getLista().size()!=uiModelo.getPropiedadesGuardadas().size()){
            UIAvisoCerrarUIModelo ui_aviso = new UIAvisoCerrarUIModelo(uiModelo,true);
            ui_aviso.setVisible(true);
        }
        else{
            uiModelo.dispose();
        }
    }
   
    
    /*
       MÉTODO QUE AL PRESIONAR UNA TECLA, SE ENCARGA DE:
       - ACTUALIZAR EL FORMATO DE CADA PALABRA DEL MODELO RESULTANTE
       - ELIMINAR LOS ARCHIVOS .dot Y .pdf DEL MODELO ANTERIOR AL MODELO
         RESULTANTE LUEGO DE PRESIONAR UNA TECLA, EN CASO EN QUE LOS ARCHIVOS
         EXISTAN
       - DESHABILITAR LAS FUNCIONALIDADES "Ver BDD", "Ver DOT", y "Chequear"
    */
    public void actualizar_keyReleassed() throws BadLocationException{ 
        String separador = System.getProperty("file.separator");
        int posicionCorrienteCursor = uiModelo.getContenedorTextoModelo().getCaretPosition();
        String rutaDOT = manipulacionArchivos.buscarRuta(separador+"DOT"+separador);
        String rutaDOTInicModelo="";
        String rutaDOTNorm="";
        String rutaDOTModelo="";
        String rutaBDD = manipulacionArchivos.buscarRuta(separador+"Graficos_BDDs"+separador);
        String rutaBDDInicModelo="";
        String rutaBDDNorm="";
        String rutaBDDModelo="";    
        if(uiModelo.getLongitudTexto() != uiModelo.getContenedorTextoModelo().getText().length()){// Si la tecla presionada no produce cambios en el texto del modeo
            /*
               Se actualiza el formato de cada palabra del modelo resultante 
            */
            ConfiguracionTexto.actualizarColoreoPalabrasReservadas(0,uiModelo.getContenedorTextoModelo().getText().length(),uiModelo.getContenedorTextoModelo());
            uiModelo.getContenedorTextoModelo().setCaretPosition(posicionCorrienteCursor);    
            /*
               Se deshabilita las opciones "Ver BDD" y "Ver DOT" del menú "Ver"
               de la pestaña "Modelo", y se deshabilita el botón chequear
               de la pestaña "Propiedad"
            */
            uiModelo.getMenuItemDOT().setEnabled(false);
            uiModelo.getMenuItemBDD().setEnabled(false);
            uiModelo.getButtonChequear().setEnabled(false);
            /*
               Se eliminan los archivos .dot y .bdd del modelo anterior al
               modelo resultante de presionar la tecla.
            */

            String ruta=uiModelo.getRutaArchivoActual().replaceAll(".mod", "");
            int indice = ruta.lastIndexOf(separador);
            indice++;
            String nombreModelo=ruta.substring(indice);
            if(!uiModelo.getRutaArchivoActual().equals("")){
                rutaDOTInicModelo = rutaDOT + nombreModelo+"_inicModelo.dot";
                rutaDOTNorm = rutaDOT + nombreModelo+"_normModelo.dot";
                rutaDOTModelo = rutaDOT + nombreModelo+"_modelo.dot";
                rutaBDDInicModelo = rutaBDD + nombreModelo+"_inicModelo.pdf";
                rutaBDDNorm= rutaBDD + nombreModelo+"_normModelo.pdf";
                rutaBDDModelo = rutaBDD + nombreModelo+"_modelo.pdf";
            }
            else{    
                rutaDOTInicModelo = rutaDOT + "DOT_inicModelo.dot";
                rutaDOTNorm = rutaDOT + "DOT_normModelo.dot";
                rutaDOTModelo = rutaDOT + "DOT_modelo.dot";
                rutaBDDInicModelo = rutaBDD + "BDD_inicModelo.pdf";
                rutaBDDNorm= rutaBDD + "BDD_normModelo.pdf";
                rutaBDDModelo = rutaBDD + "BDD_modelo.pdf";
            }
            manipulacionArchivos.eliminarArchivo(rutaDOTInicModelo);
            manipulacionArchivos.eliminarArchivo(rutaDOTNorm);
            manipulacionArchivos.eliminarArchivo(rutaDOTModelo);
            manipulacionArchivos.eliminarArchivo(rutaBDDInicModelo);
            manipulacionArchivos.eliminarArchivo(rutaBDDNorm);
            manipulacionArchivos.eliminarArchivo(rutaBDDModelo);
        }  
        uiModelo.setEsModeloEditado(true);//Se registra que es un modelo editado
        uiModelo.setResultadoAnalisisModelo("");//Se resetea resultado de análisis sintáctico y semántico del modelo
    }

    

    
    
    /*
       -----------------------------------------------------------------------
       ---------------------------MÉTODOS PRIVADOS----------------------------
       -----------------------------------------------------------------------
    */
    
    
    
    
    /*
       MÉTODO QUE DADO UN BDD 'bdd' Y UNA LISTA DE BDD's 'listaBDD' CON DATOS 
       ASOCIADOS A CADA UNO:
         - SI 'bdd' ESTÁ CONTENIDO EN LA LISTA, RETORNA UN PAR CON DATOS 
           ASOCIADOS A 'bdd' 
         - SI 'bdd' NO ESTÁ CONTENIDO EN LA LISTA, RETORNA UN PAR (null,null)
    */
    private  Par contiene(BDD bdd, List listaBDD){
       
        String clave=null;
        Integer nro = null;
        int i=0;
        while((i<listaBDD.size())&&(clave==null)){
            Terna ternaCorriente = (Terna)listaBDD.get(i);
            BDD bddCorriente = (BDD) ternaCorriente.getTercero();
            if((bddCorriente).equals(bdd)){
                clave = (String) ((Terna)listaBDD.get(i)).getPrimero();
                nro = (Integer) ((Terna)listaBDD.get(i)).getSegundo();
            }
            i++;
        }
        return new Par(clave,nro);
    }
    
    
    public String obtenerVariable(List variablesDeclaradas, int nivel){
       
        if(nivel<variablesDeclaradas.size()){
            return (String)variablesDeclaradas.get(nivel);
        }
        else{
            return ((String)variablesDeclaradas.get(nivel-variablesDeclaradas.size()))+"´";
        }
    }
    
    
    /*
        MÉTODO QUE GENERA DOT DEL BDD DADO POR EL PARÁMETRO bdd, ASOCIADO A UN
        MODELO CON LAS VARIABLES DECLARADAS DADAS POR EL PARÁMETRO 
        variablesDeclaradas
    */
    private String obtenerDOT(BDD bdd, List variablesDeclaradas)throws FileNotFoundException, IOException{
        
        String dot="digraph G {\n";     
        dot=dot + "falso [shape=box, label=\"0\", style=filled, shape=box, height=0.3, width=0.3];\n";
        dot=dot + "verdadero [shape=box, label=\"1\", style=filled, shape=box, height=0.3, width=0.3];\n";
        dot=dot + generarRelacionesDOT(bdd, variablesDeclaradas);       
        dot=dot + "}";
        return dot;
    }
    
    
    /*
        MÉTODO QUE GENERA LAS "RELACIONES DOT" ENTRE LOS NODOS DEL BDD DADO 
        POR EL PARÁMETRO 'bdd', ASOCIADO A UN MODELO CON LAS VARIABLES 
        DECLARADAS DADAS POR EL PARÁMETRO 'variablesDeclaradas'
    */
    private String generarRelacionesDOT(BDD bdd, List variablesDeclaradas) throws IOException {
       
        /*
            Inicialización de la cadena que almacena el DOT, con cadena vacía
        */
        String dot="";
        if((!bdd.isOne())&&(!bdd.isZero())){
            /*
                Inicialización de la variables utilizadas en el ciclo:
                (subárbol izquierdo de un nodo de 'bdd' se representa con línea
                 punteada, y subárbol derecho de un nodo de 'bdd' se representa
                 con línea continua )
                  - ColaDinamica: Cola que almacena los subárboles de un nodo 
                    'bdd' (hijo izquierdo e hijo derecho)
                  - nroNodo_igualNivel: Número de nodo en un nivel de 'bdd'
                  - nuevaVariable: Nombre de la variable asociada a los nodos 
                    del siguiente nivel del nivel corriente, de 'bdd'
                  - bddHijoIzquierdo: Subárbol izquierdo del subárbol de 'bdd',
                    que tiene como raíz el nodo corriente
                  - bddHijoDerecho: Subárbol derecho del subárbol de 'bdd',
                    que tiene como raíz el nodo corriente
                  - vble_isomorfismo_hijoIzq: Variable asociada a la raíz de
                    un subárbol izquierdo de 'bdd', que tiene al menos otro
                    padre (isomorfismo en el árbol de decisión binario 
                    correspondiente al 'bdd')
                  - vble_isomorfismo_hijoDer: Variable asociada a la raíz de
                    un subárbol derecho de 'bdd', que tiene al menos otro padre 
                    (isomorfismo en el árbol de decisión binario correspondiente 
                    al 'bdd')
                  - nroNodo_isomorfismo_hijoIzq:  Número del nodo que
                    es raíz de un subárbol izquierdo de 'bdd', que tiene al 
                    menos otro padre (isomorfismo en el árbol de decisión 
                    binario correspondiente al 'bdd')
                  - nroNodo_isomorfismo_hijoIzq:  Número del nodo que
                    es raíz de un subárbol derecho de 'bdd', que tiene al 
                    menos otro padre (isomorfismo en el árbol de decisión 
                    binario correspondiente al 'bdd')
                  - nivelCorriente: Nivel del nodo corriente
                  - listaBDD_visitados: Lista de subárboles de 'bdd', cuyas 
                    raíces fueron encoladas
                  - ultimoBDD: Último subárbol de 'bdd' encolado
                  - ternaCorriente: Almacena información a encolar sobre
                    un subárbol de 'bdd'. Los datos son, el nombre de variable 
                    y número, asociados al nodo raíz del subárbol de 'bdd', y 
                    el subárbol de 'bdd'
                  - variableCorriente: Nombre de la variable corriente asociada
                    al nodo corriente
                  - nroNodo_igualNivelCorriente: Número del nodo corriente,
                    en el nivel corriente             
            */
            ColaDinamica cola =  new ColaDinamica();
            String nuevaVariable="";
            BDD bddHijoIzquierdo=null;
            BDD bddHijoDerecho=null;
            String vble_isomorfismo_hijoIzq="";
            String vble_isomorfismo_hijoDer="";
            Integer nroNodo_isomorfismo_hijoIzq=null;
            Integer nroNodo_isomorfismo_hijoDer=null;
            List listaBDD_visitados = new LinkedList();
            Terna ternaCorriente = null;
            String variableCorriente=null;
            Integer idNodo= new Integer(1);
            Integer idCorriente= null;
            
            /*
               Se encola, datos del 'bdd' 
            */
            
            cola.add(new Terna((String)variablesDeclaradas.get(0),new Integer(1),bdd));
            listaBDD_visitados.add(new Terna((String)variablesDeclaradas.get(0),new Integer(1),bdd));
            
            while(!cola.isEmpty()){ // Mientras la cola no esté vacía 

                /*
                    Se desencola, y se almacenan los datos desencolados 
                    asociados al 'bdd' (primero en enocolarse) ó a un subárbol
                    de 'bdd'
                */
                
                ternaCorriente = (Terna)cola.remove();
                variableCorriente = (String)ternaCorriente.getPrimero();
                idCorriente = (Integer)ternaCorriente.getSegundo();
                BDD bddCorriente = (BDD)ternaCorriente.getTercero();
                int nivelCorriente = bddCorriente.level();
                dot=dot+variableCorriente+"_"+idCorriente+" [label=\""+obtenerVariable(variablesDeclaradas,nivelCorriente)+"_"+(bddCorriente.level()+1)+"\"];\n";
                bddHijoIzquierdo = bddCorriente.low(); // Se almacena subárbol izquierdo del nodo corriente
                bddHijoDerecho = bddCorriente.high();  // Se almacena subárbol derecho del nodo corriente   
                nuevaVariable="";
                if((nivelCorriente + 1)<variablesDeclaradas.size()){ // Si el nivel siguiente al corriente no corresponde a nivel asociado a variable primada
                    nuevaVariable = obtenerVariable(variablesDeclaradas,nivelCorriente+1);
                }
                else{ // Si el nivel siguiente al corriente corresponde a nivel asociado a variable primada
                    if(((nivelCorriente+1)-variablesDeclaradas.size())!=variablesDeclaradas.size()){
                        nuevaVariable = obtenerVariable(variablesDeclaradas,(nivelCorriente+1));
           
                    }
                }
                       
 
                        /*
                           Se detecta si el subárbol izquierdo del nodo corriente,
                           tiene almenos otro padre,es decir se detecta si en el
                           árbol de decisión binario, hay isomorfismo entre el
                           subárbol izquierdo del nodo corriente y otro subárbol.
                           Si hay isomorfismo, se almacena el nombre de variable y 
                           número, asociado al nodo raíz del subárbol izquierdo del
                           nodo corriente
                        */

                     
                        if(bddHijoIzquierdo!=null){
                        vble_isomorfismo_hijoIzq = (String) ((Par) contiene(bddHijoIzquierdo,listaBDD_visitados)).getPrimero();
                        nroNodo_isomorfismo_hijoIzq = (Integer) ((Par) contiene(bddHijoIzquierdo,listaBDD_visitados)).getSegundo();
                        }                           
                        if((vble_isomorfismo_hijoIzq == null)&&(bddHijoIzquierdo != null)&&(!bddHijoIzquierdo.isOne())&&(!bddHijoIzquierdo.isZero())){
                                idNodo++;
                                cola.add(new Terna(nuevaVariable,(idNodo),bddHijoIzquierdo));
                                listaBDD_visitados.add(new Terna(nuevaVariable,(idNodo),bddHijoIzquierdo));
                                dot=dot + variableCorriente+"_"+idCorriente+" -> "+(nuevaVariable+"_"+(idNodo))+" [style=dotted];\n";    
                            
                        
                            /*
                               Si el subárbol izquierdo del nodo corriente no es hoja
                               "verdadero", se agrega a la cadena que almacena el DOT, 
                               la relación entre el nodo corriente y hoja "verdadero"
                            */
                        }
                            if((bddHijoIzquierdo.isOne())){ 
                                dot=dot + variableCorriente+"_"+idCorriente  +" -> "+"verdadero"+" [style=dotted];\n";
                            }
                    
                            /*
                               Si el subárbol izquierdo del nodo corriente no es hoja
                               "falso", se agrega a la cadena que almacena el DOT, 
                               la relación entre el nodo corriente y hoja "falso"
                            */
                            if((bddHijoIzquierdo.isZero())){ 
                                dot=dot + variableCorriente+"_"+idCorriente +" -> "+"falso"+" [style=dotted];\n";
                            }        
                        
                        if(bddHijoDerecho!=null){
                        vble_isomorfismo_hijoDer = (String) ((Par) contiene(bddHijoDerecho,listaBDD_visitados)).getPrimero();
                        nroNodo_isomorfismo_hijoDer = (Integer) ((Par) contiene(bddHijoDerecho,listaBDD_visitados)).getSegundo();
                        }
                        if((vble_isomorfismo_hijoDer == null)&&(bddHijoDerecho != null)&&(!bddHijoDerecho.isOne())&&(!bddHijoDerecho.isZero())){
                                idNodo++;
                                cola.add(new Terna(nuevaVariable,(idNodo),bddHijoDerecho));
                                listaBDD_visitados.add(new Terna(nuevaVariable,(idNodo),bddHijoDerecho));
                                dot=dot + variableCorriente+"_"+idCorriente+" -> "+(nuevaVariable+"_"+(idNodo))+" [style=filled];\n";
                            
                        }
                            if((bddHijoDerecho.isOne())){ 
                                dot=dot + variableCorriente+"_"+idCorriente +" -> "+"verdadero"+" [style=filled];\n";
                            }
                    
                            /*
                               Si el subárbol izquierdo del nodo corriente no es hoja
                               "falso", se agrega a la cadena que almacena el DOT, 
                               la relación entre el nodo corriente y hoja "falso"
                            */
                            if((bddHijoDerecho.isZero())){ 
                                dot=dot + variableCorriente+"_"+idCorriente +" -> "+"falso"+" [style=filled];\n";
                            }   
                        

             
                    
                        /*
                           Si hay isomorfismo con el subárbol izquierdo del nodo
                           corriente, se agrega a la cadena que almacena el DOT, 
                           la relación entre el nodo corriente y el nodo que
                           es raíz de un subárbol izquierdo de 'bdd', que tiene al 
                           menos otro padre
                        */
                        if(vble_isomorfismo_hijoIzq != null){
                            dot=dot + variableCorriente+"_"+(idCorriente)+" -> "+(vble_isomorfismo_hijoIzq+"_"+nroNodo_isomorfismo_hijoIzq)+" [style=dotted];\n";
                        }
                    
                        /*
                           Si hay isomorfismo con el subárbol derecho del nodo
                           corriente, se agrega a la cadena que almacena el DOT, 
                           la relación entre el nodo corriente y el nodo que
                           es raíz de un subárbol derecho de 'bdd', que tiene al 
                           menos otro padre
                        */
                        if(vble_isomorfismo_hijoDer != null){
                            dot=dot + variableCorriente+"_"+(idCorriente)+" -> "+(vble_isomorfismo_hijoDer+"_"+nroNodo_isomorfismo_hijoDer)+" [style=filled];\n";
                        }
                
            }
        }
        return dot;
     }

}
