package Interfaz.Eventos.EventosUIPropiedad;


import AnalizadorModelo.AuxiliarModelo.Par;
import Interfaz.InterfazGrafica.UIAvisoErrorPropiedad;
import Interfaz.InterfazGrafica.UIAvisoPropiedadRepetida;
import Interfaz.InterfazGrafica.UIModelo;
import Interfaz.InterfazGrafica.UIPropiedadDCTL;
import AnalizadorPropiedades.AuxiliarPropiedades.ListaVariablesModelo;
import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import java.awt.event.ActionEvent;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java_cup.runtime.Symbol;
import java_cup.runtime.SymbolFactory;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import AnalizadorPropiedades.LexerParser.Lexer_dCTL;
import AnalizadorPropiedades.LexerParser.Parser_dCTL;
import Interfaz.AuxiliarInterfaz.ManipulacionListas;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class EventosPropiedad {

/*
   Una instancia de 'EventosPropiedad' está asociada a una única instancia de 
   UIModelo y UIPropiedadDCTL y ManipulacionArchivos (definidos en la sección
   de atributos)
*/ 
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private UIModelo uiModelo;
    private UIPropiedadDCTL uiPropiedad;
    private ManipulacionArchivos manipulacionArchivos;
    private String propiedadAEditar;
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        -----------------------------CONSTRUCTORES---------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public EventosPropiedad(UIModelo uiModelo){
        this.uiModelo = uiModelo;
        manipulacionArchivos = new ManipulacionArchivos(uiModelo);
    }
    
    public EventosPropiedad(UIModelo uiModelo, UIPropiedadDCTL uiPropiedad){
        this.uiModelo = uiModelo;
        this.uiPropiedad = uiPropiedad;
        manipulacionArchivos = new ManipulacionArchivos(uiModelo);
    }
    
    
    /*
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
       ---------------------------MÉTODOS PÚBLICOS----------------------------
       -----------------------------------------------------------------------
       -----------------------------------------------------------------------
    */
    
    
    /*
          MÉTODO QUE ABRE ARCHIVOS .dCTL, ALMACENADOS EN EL DIRECTORIO 
          SELECCIONADO POR EL USUARIO. LAS PROPIEDADES ABIERTAS SE AGREGAN A LA 
          LISTA DE PROPIEDADES. UNA VEZ QUE LA LISTA DE PROPIEDADES CONTENGA
          AL MENOS UNA PROPIEDAD, SE HABILITAN MÁS FUNCIONALIDADES SOBRE 
          PROPIEDADES
    */
      public void abrirPropiedades() throws UnsupportedEncodingException, Exception{
        uiModelo.getButtonChequear().setEnabled(false);
        JFileChooser jFileChooser = new JFileChooser();
        /*
           Se define que la extensión de los archivos que se pueden 
           abrir, es ".dCTL"
        */
        jFileChooser.setAcceptAllFileFilterUsed(false);
        jFileChooser.setFileFilter(new FileNameExtensionFilter("todos los archivos *.dCTL", "dCTL","dCTL"));
        jFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (!jFileChooser.isMultiSelectionEnabled()) {
            jFileChooser.setMultiSelectionEnabled(true);
        }
        int resultado = jFileChooser.showOpenDialog(uiModelo);//Se visualiza ventana que
                                                              //permite buscar el archivo
                                                              //a abrir, navegando por
                                                              //los directorios de la computadora
        switch(resultado){
            case JFileChooser.APPROVE_OPTION://Si se presiona botón Aceptar
                 {
                      /* Se almacenan los ficheros seleccionados, en 'ficheros' */
                      File[] ficheros = jFileChooser.getSelectedFiles();
                      String rutaPropiedadAbiertas = (jFileChooser.getSelectedFile().toString());
                      boolean hayPropiedadRepetida = false;
                      /*
                         Abrir una propiedad, implica agregar la misma a la 
                         lista de propiedades de la pestaña "Propiedad" de la
                         ventana sobre la que se especifica el modelo.
                         Cada propiedad abierta se visualiza en la lista de 
                         propiedades, en color negro (indicando que es
                         propiedad guardada). Y cada propiedad abierta, 
                         se almacena en la lista de propiedades guardadas.
                         Se habilitan las funcionalidades "eliminar", "vaciar", 
                         "editar, "guardar" y "copiar" propiedades.
                      */
                      for(int i=0;i<ficheros.length;i++){
                          try {
                             String propiedadCorriente = manipulacionArchivos.obtenerContenidoArchivo(ficheros[i]);
                             String propiedad = propiedadCorriente.replaceAll("<html><font color=black>", "<html><font color=gray>");
                             if((!propiedadCorriente.trim().equals(""))&&
                                (!uiModelo.getLista().contains(propiedadCorriente))&&
                                (!uiModelo.getLista().contains(propiedad))){//Si la propiedad a abrir no estaba contenida en al lista de propiedades (guardada o no)
                                 
                                 uiModelo.getLista().addElement(propiedadCorriente);
                                 uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                                 propiedadCorriente = quitarFormatoHTML(propiedadCorriente);
                                 Par propiedadAbierta= new Par(propiedadCorriente,ficheros[i].getAbsolutePath());
                                 uiModelo.getLista_rutaPropiedad().add(propiedadAbierta);
                                                                 
                                 uiModelo.getPropiedadesGuardadas().add(propiedadCorriente);
                                 uiModelo.getMenuItemEliminarPropiedad().setEnabled(true);
                                 uiModelo.getMenuItemVaciarLista().setEnabled(true);
                                 uiModelo.getMenuItemEditarPropiedad().setEnabled(true);
                                 uiModelo.getMenuItemGuardarPropiedad().setEnabled(true);
                                 uiModelo.getMenuItemCopiarPropiedad().setEnabled(true);
                             }
                             else{//Si la propiedad a abrir estaba conenida en la lista de propiedades
                                 hayPropiedadRepetida = true;
                             }
                             
                          }
                          catch (IOException ex) {
                              //Logger.getLogger(uiModelo.class.getName()).log(Level.SEVERE, null, ex);
                          }
                      }   
                      if(hayPropiedadRepetida){//Si al menos una de las propiedades a abrir ya estaba en la lista de propiedades
                          UIAvisoPropiedadRepetida uiAvisoPropiedadRepetida = new UIAvisoPropiedadRepetida(uiModelo,true);
                          uiAvisoPropiedadRepetida.setVisible(true);
                      }
                 }
            case JFileChooser.CANCEL_OPTION://Si se presiona botón Cancelar
                                              {
                                                   jFileChooser.removeAll();
                                              }
        }
    }
    
    
 
    /*
        MÉTODO QUE ELIMINA UNA PROPIEDAD SELECCIONADA, DE LA LISTA DE 
        PROPIEDADES DEL MODELO. UNA VEZ ELIMINADA LA PROPIEDAD, 
        DEPENDIENDO DE LA LISTA DE PROPIEDADES RESULTANTE LUEGO DE LA 
        ELIMINACIÓN, SE DESHABILITAN O NO FUNCIONALIDADES SOBRE PROPIEDADES 
    */
    public void eliminarPropiedad(){
     if(!uiModelo.getListaPropiedad().isSelectionEmpty()){//Si no hay propiedad de la lista de propiedades, seleccionada para eliminar
           String propiedadAEliminar = (String)uiModelo.getListaPropiedad().getSelectedValue();
           propiedadAEliminar=quitarFormatoHTML(propiedadAEliminar);
           Par par = ManipulacionListas.buscar_listaRutaPropiedad(uiModelo.getLista_rutaPropiedad(), propiedadAEliminar);
           uiModelo.setLista_rutaPropiedad(ManipulacionListas.eliminar_rutaPropiedad(uiModelo.getLista_rutaPropiedad(), par));
           uiModelo.getLista().remove(uiModelo.getListaPropiedad().getSelectedIndex());
           uiModelo.getPropiedadesGuardadas().remove(par.getPrimero());             
       }
       
       /*
          Luego de eliminar la propiedad, de la lista de propiedades, y de la lista de propiedades
          guardadas (en el caso que la propiedad fue guardada)
       */
       if(uiModelo.getLista().isEmpty()){//Si no hay al menos una propiedad en la lista de propiedades
           /*
              Se deshabilitan las opciones, editar, eliminar, vaciar , guardar y copiar propiedad 
           */
           uiModelo.getMenuItemEditarPropiedad().setEnabled(false);
           uiModelo.getMenuItemEliminarPropiedad().setEnabled(false);
           uiModelo.getMenuItemVaciarLista().setEnabled(false);
           uiModelo.getMenuItemGuardarPropiedad().setEnabled(false);
           uiModelo.getMenuItemCopiarPropiedad().setEnabled(false);
       }
       if(uiModelo.getListaPropiedad().isSelectionEmpty()){//Si no hay propiedad seleccionada
           
           /*
              Se deshabilita la opción de chequear propiedades sobre el modelo 
           */
           uiModelo.getButtonChequear().setEnabled(false);
       }

   }
    
    /*
       MÉTODO QUE ELIMINA TODAS LAS PROPIEDADES, DE LA LISTA DE PROPIEDADES.
       UNA VEZ QUE SE VACÍA LA LISTA DE PROPIEDADES, SE DESHABILITAN 
       FUNCIONALIDADES SOBRE PROPIEDADES 
    */
       public void vaciarLista(){
           uiModelo.getLista().removeAllElements();
           
           /*
              Se deshabilitan las opciones, editar, eliminar, vaciar , guardar y copiar propiedad 
           */
           uiModelo.getMenuItemEditarPropiedad().setEnabled(false);
           uiModelo.getPropiedadesGuardadas().clear();
           uiModelo.getButtonChequear().setEnabled(false);
           uiModelo.getMenuItemEliminarPropiedad().setEnabled(false);
           uiModelo.getMenuItemVaciarLista().setEnabled(false);
           uiModelo.getMenuItemGuardarPropiedad().setEnabled(false);
           uiModelo.getMenuItemCopiarPropiedad().setEnabled(false);
           uiModelo.getLista_rutaPropiedad().clear();
           uiModelo.getPropiedadesGuardadas().clear();
    }
  
    
    
    /*
       MÉTODO QUE REGISTRA LA PROPIEDAD SELECCIONADA PARA COPIAR. 
    */   
    public void copiarPropiedad(){
        if(!uiModelo.getListaPropiedad().isSelectionEmpty()){//Si se selecciona propiedad para copiar
            String propiedadAPegar = (String)uiModelo.getListaPropiedad().getSelectedValue();
            propiedadAPegar=quitarFormatoHTML(propiedadAPegar);
            uiModelo.setPropiedadAPegar(propiedadAPegar);
        }
    }
    

  
    /*
       MÉTODO QUE HABILITA Ó DESHABILITA EL BOTÓN "Chequear" DE LA PESTAÑA
       "Propiedad" DEPENDIENDO SI LA PROPIEDAD PASADA COMO PARÁMETRO ES O NO 
       SINTÁCTICA Y SEMÁNTICAMENTE CORRECTA. SE HABILITA SI ES CORRECTA, 
       EN CASO CONTRARIO SE DESHABILITA EL BOTÓN "Chequear".
       RETORNA EL RESULTADO DEL ANÁLISIS SINTÁCTICO Y SEMÁNTICO DE LA PROPIEDAD
       DADA COMO PARÁMETRO
    */      
    public String habilitar_deshabilitar_chequear(String propiedad) throws UnsupportedEncodingException, Exception{

        /*
           Se registra en el método estático de la clase 'ListaVariablesModelo',
           las variables declaradas en el modelo
        */
        ListaVariablesModelo.setListaVariables(uiModelo.getVbleDecl());
        
        /*
           Se almacena la propiedad a analizar su sinaxis y semántica, sin
           formato HTML
        */
        propiedad=quitarFormatoHTML(propiedad);
        
        /*
           Si la propiedad no termina con ";", se añade al final ";"
        */
        if(!propiedad.endsWith(";")){
            propiedad=propiedad+";";
        }
        
        InputStream is=null;
        is = new ByteArrayInputStream(propiedad.getBytes("UTF-8"));

        /*
           Se realiza parsing para analizar sintáctica y semánticamente 
           la propiedad: Se crea instancia de InputStream a partir de la
           propiedad. Se crea instancia de lexer a partir de la instancia
           InputStream. Se crea parser a partir del lexer.
        */
        Lexer_dCTL lexerPropiedad = new Lexer_dCTL(is, new SymbolFactory() {

           @Override
            public Symbol newSymbol(String string, int i, Symbol symbol, Symbol symbol1, Object o) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public Symbol newSymbol(String string, int i, Symbol symbol, Symbol symbol1) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public Symbol newSymbol(String string, int i, Object o) {
                return new Symbol(i,o);
            }

            @Override
            public Symbol newSymbol(String string, int i) {
               return new Symbol(i);
            }

            @Override
            public Symbol startSymbol(String string, int i, int i1) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        Parser_dCTL parserPropiedad = new Parser_dCTL (lexerPropiedad);    
        parserPropiedad.parse();//realiza el parsing
        uiModelo.setFormula(parserPropiedad.obtenerFormula());
        
        /*
           Se almacena resultado del análisis sintáctico y semántico
        */
        String resultadoAnalisisPropiedad = parserPropiedad.obtenerResultado();
        if((uiModelo.getResultadoAnalisisModelo().equals("ANÁLISIS SINTÁCTICO Y SEMÁNTICO EXITOSO"))&&
           (resultadoAnalisisPropiedad.equals("EXITO"))&&(uiModelo.getBDDModelo()!=null)){//Si en la pestaña "Modelo" se especificó un modelo
                                                                                          //sintáctica y semánticamente correcto y que soporta BDD's, 
                                                                                          //y si la propiedad analizada es sintáctica y semánticamente 
                                                                                          //correcta
                                                                                         
            /*
               Se habilita el botón chequear de la pestaña "Propiedad" de la ventana
               sobre la que se especifica un modelo
            */
            uiModelo.getButtonChequear().setEnabled(true);
        }
        else{//Si en la pestaña "Modelo" no se especificó un modelo ó no es
             //sintáctica y semánticamente correcto, ó es modelo que no soporta BDD's, 
             //ó si la propiedad analizada no es sintáctica y semánticamente correcta
            
            /*
               Se deshabilita el botón chequear de la pestaña "Propiedad" de la ventana
               sobre la que se especifica un modelo
            */
            uiModelo.getButtonChequear().setEnabled(false);
        }
    
        return resultadoAnalisisPropiedad;
      }
      
  
    /*
       MÉTODO QUE REGISTRA EN LA LISTA DE PROPIEDADES dCTL, UNA NUEVA PROPIEDAD
       Ó UNA PROPIEDAD EDITADA, CON POSIBILIDAD DE GUARDAR EN ARCHIVO. 
       SI SE EDITA UNA PROPIEDAD QUE PREVIAMENTE FUE GUARDADA, SE SOBREESCRIBE 
       EL ARCHIVO QUE CONTIENE AL PROPIEDAD A EDITAR
       LAS PROPIEDADES GUARDADAS, SE LAS VISUALIZAN CON COLOR NEGRO Y LAS
       PROPIEDADES NO GUARDADAS SE VISUALIZAN CON COLOR GRIS
    */
    public void guardarPropiedad(ActionEvent e) throws IOException, Exception{
            
            /*
               Se analiza sintáctica y semánticamente la propiedad a registrar
               en la lista de propiedades, habilitando ó deshabilitando el botón
               "Chequear" según el caso
            */
            String resultadoAnalisisPropiedad = habilitar_deshabilitar_chequear(uiPropiedad.getContenedorTextoPropiedad().getText());         
            boolean esPropiedadGuardada = false;
            if((!uiPropiedad.getContenedorTextoPropiedad().getText().trim().equals(""))&&(!uiModelo.getLista().contains("<html><font color=gray>"+
                uiPropiedad.getContenedorTextoPropiedad().getText()+"</font></html>"))&&
                (!uiModelo.getLista().contains("<html><font color=black>"+
                 uiPropiedad.getContenedorTextoPropiedad().getText()+"</font></html>"))){//Si la propiedad a editar o agregar en la lista de propiedades, 
                                                                                         //(guardada o no), no está en la lista de propiedades
                
                /*
                   Si se eligió editar una propiedad
                */
                if((e.getSource()==uiModelo.getMenuItemEditarPropiedad())||(e.getSource()==uiModelo.getMenuItemPopupEditar())){
                    uiModelo.getButtonChequear().setEnabled(false);
                    String propiedadAEditar = (String) uiModelo.getListaPropiedad().getSelectedValue();
                    String propiedadAEditarSinHTML = quitarFormatoHTML(propiedadAEditar);
                    uiModelo.setPropiedadAEditar(propiedadAEditarSinHTML);
                    boolean esPropiedadAEditarGuardada = false;
                    /*
                       Si la propiedad a editar está guardada en archivo, se 
                       registra la situación
                    */
                    if(uiModelo.getPropiedadesGuardadas().contains(propiedadAEditarSinHTML)){
                        esPropiedadAEditarGuardada = true;
                    }
                    
                    /*
                       Se almacena el índice de la lista de propiedades registradas, donde se
                       se encuentra la propiedad a editar
                    */
                    int indice = ManipulacionListas.buscarIndice_propiedadListModel(uiModelo.getLista(), propiedadAEditar);
                    
                    /*
                       Se elimina de la lista de propiedades guardadas, la propiedad a editar, en
                       caso que la misma estuviera guardada
                    */
                    uiModelo.getPropiedadesGuardadas().remove(propiedadAEditarSinHTML);
                    
                    /*
                       Si la propiedad editada es léxica, sintáctica y semánticamente correcta 
                    */
                    if(resultadoAnalisisPropiedad.equals("EXITO")){
                        String propiedad = "<html><font color=black>"+uiPropiedad.getPropiedad()+"</font></html>";
                        
                        /*
                           Se reemplaza de la lista de propiedades registradas en el índice 
                           'indice', la propiedad a editar por la propiedad editada, con color de
                           letra negro                        
                        */
                        uiModelo.getLista().set(indice, propiedad);
                        uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                        Par par = new Par("","");
                        if(esPropiedadAEditarGuardada){//Si la propiedad a editar está guardada      
                            
                            /*
                               Se agrega a la lista de propiedades guardadas, la propiedad editada
                               Se reescribe el archivo que contiene la propiedad a editar, por la 
                               propiedad guardada
                            */
                            uiModelo.getPropiedadesGuardadas().add(uiPropiedad.getPropiedad());
                            par = ManipulacionListas.buscar_listaRutaPropiedad(uiModelo.getLista_rutaPropiedad(),propiedadAEditarSinHTML);
                            manipulacionArchivos.guardar((String)par.getSegundo(), "<html><font color=black>"+uiPropiedad.getPropiedad()+"</font></html>", "dCTL");
                            /*
                               Se elimina de la lista de pares donde cada par contiene una 
                               propiedad guardada y el directorio donde se encuentra el archivo
                               que contiene dicha propiedad, el par que contiene la propiedad a
                               editar. Y se agrega a dicha lista el par que contiene la propiedad
                               editada y el mismo directorio de archivo de la propiedad a editar  
                            */
                            uiModelo.setLista_rutaPropiedad(ManipulacionListas.eliminar_rutaPropiedad(uiModelo.getLista_rutaPropiedad(), par));
                            par.setPrimero(uiPropiedad.getPropiedad());
                            uiModelo.getLista_rutaPropiedad().add(par);
                        }
                        else{//Si la propiedad a editar no está guardada 
                            
                            /*
                               Se permite guardar la propiedad editada en un directorio
                            */
                            par = manipulacionArchivos.guardarComo("<html><font color=black>"+uiPropiedad.getPropiedad()+"</font></html>", "dCTL");    
                            par.setPrimero(propiedadAEditarSinHTML);
                            if(((String)par.getSegundo()).equals("")){//Si la propiedad editada no está guardada en archivo
                                
                                /*
                                   Se cambia el color de letra de la propiedad editada ya 
                                   registrada en la lista de propiedades, por color gris 
                                */
                                propiedad = "<html><font color=gray>"+uiPropiedad.getPropiedad()+"</font></html>";
                                uiModelo.getLista().set(indice, propiedad);
                                uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                            }
                            else{//Si la propiedad editada está guardada en archivo
                                
                                /*
                                  Se elimina de la lista de pares, el par que contiene la propiedad a
                                  editar. Y se agrega a dicha lista el par que contiene la 
                                  propiedad editada y el mismo directorio de archivo de la 
                                  propiedad a editar.
                                  Se agrega a la lista de propiedades guardadas, la propiedad editada
                                */
                                par.setPrimero(propiedadAEditarSinHTML);
                                uiModelo.setLista_rutaPropiedad(ManipulacionListas.eliminar_rutaPropiedad(uiModelo.getLista_rutaPropiedad(), par));
                                par.setPrimero(uiPropiedad.getPropiedad());
                                uiModelo.getLista_rutaPropiedad().add(par);
                                uiModelo.getPropiedadesGuardadas().add(uiPropiedad.getPropiedad());
                            }
                        }
                        
                    }
                    /*
                       Si la propiedad editada es léxica, sintáctica y/o semánticamente incorrecta
                    */
                    if(!resultadoAnalisisPropiedad.equals("EXITO")){
                        
                        /*
                           Se reemplaza de la lista de propiedades registradas en el índice 
                           'indice', la propiedad a editar por la propiedad editada, con color de
                           letra gris. Y se da aviso del error léxico, sintáctico, semántico de
                           la propiedad editada, con la posibilidad de guardarla en archivo
                        */
                        String propiedad = "<html><font color=gray>"+uiPropiedad.getPropiedad()+"</font></html>";
                        uiModelo.getLista().set(indice, propiedad);
                        uiModelo.getButtonChequear().setEnabled(false);
                        UIAvisoErrorPropiedad uiAvisoErrorPropiedad = new UIAvisoErrorPropiedad(uiModelo,uiPropiedad,true,this);
                        uiAvisoErrorPropiedad.setError(resultadoAnalisisPropiedad);
                        uiAvisoErrorPropiedad.setVisible(true);
                    }

                }  
                
                /*
                   Si se eligió nueva propiedad                
                */
                if((e.getSource()==uiModelo.getMenuItemNuevaPropiedad())&&(!uiPropiedad.getContenedorTextoPropiedad().getText().trim().equals(""))){
                    
                    /*
                       Si la propiedad a agregar es léxica, sintáctica y semánticamente correcta 
                    */
                    if(resultadoAnalisisPropiedad.equals("EXITO")){
                        
                        /*
                           Se permite guardar la propiedad a agrega en un directorio
                        */
                        Par par = manipulacionArchivos.guardarComo("<html><font color=black>"+uiPropiedad.getPropiedad()+"</font></html>", "dCTL");    
                        if(!par.getPrimero().equals("")){//Si la propiedad a agregar está guardada en archivo
                            
                            /*
                               Se agrega a la lista de propiedades registradas la propiedad nueva
                               propiedad, con color de letra negro                        
                            */
                            uiModelo.getLista().addElement("<html><font color=black>"+uiPropiedad.getContenedorTextoPropiedad().getText()+"</font></html>");
                            uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                            uiModelo.getListaPropiedad().setSelectedIndex(uiModelo.getLista().getSize()-1);    
                            
                            /*
                               Se agrega a la lista de pares donde cada par contiene una 
                               propiedad guardada y el directorio donde se encuentra el archivo
                               que contiene dicha propiedad, el par que contiene la propiedad a
                               agregar en el direcotrio elegido. 
                            */
                            par.setPrimero(uiPropiedad.getPropiedad());
                            uiModelo.getLista_rutaPropiedad().add(par);
                            uiModelo.getPropiedadesGuardadas().add(uiPropiedad.getPropiedad());
                        }
                        else{//Si la propiedad a agregar no está guardada en archivo
                            uiModelo.getLista().addElement("<html><font color=gray>"+uiPropiedad.getContenedorTextoPropiedad().getText()+"</font></html>");
                            uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                            uiModelo.getListaPropiedad().setSelectedIndex(uiModelo.getLista().getSize()-1);    
                        }
                    }
                    
                    /*
                       Si la propiedad a agregar no es léxica, sintáctica ó semánticamente correcta 
                    */
                    if(!resultadoAnalisisPropiedad.equals("EXITO")){
                        /*
                           Se agrega a la lista de propiedades registradas la propiedad nueva
                           propiedad, con color de letra gris. Y se da aviso del error léxico, 
                           sintáctico, semántico de la propiedad agregada, con la posibilidad de 
                           guardarla en archivo                      
                        */
                        uiModelo.getLista().addElement("<html><font color=gray>"+uiPropiedad.getContenedorTextoPropiedad().getText()+"</font></html>");
                        uiModelo.getListaPropiedad().setModel(uiModelo.getLista());
                        uiModelo.getListaPropiedad().setSelectedIndex(uiModelo.getLista().getSize()-1);
                        uiModelo.getButtonChequear().setEnabled(false);
                        UIAvisoErrorPropiedad uiAvisoErrorPropiedad = new UIAvisoErrorPropiedad(uiModelo,uiPropiedad,true,this);
                        uiAvisoErrorPropiedad.setError(resultadoAnalisisPropiedad);
                        uiAvisoErrorPropiedad.setVisible(true);
                    }
                }   

                /*
                   Se habilitan las opciones editar, eliminar, vaciar, guardar y copiar propiedad
                */
                uiModelo.getMenuItemEditarPropiedad().setEnabled(true);
                uiModelo.getMenuItemEliminarPropiedad().setEnabled(true);
                uiModelo.getMenuItemVaciarLista().setEnabled(true);
                uiModelo.getMenuItemGuardarPropiedad().setEnabled(true);
                uiModelo.getMenuItemCopiarPropiedad().setEnabled(true);
                uiPropiedad.dispose();
            }
            else{//Si la propiedad a editar o agregar en al lista de propiedades, 
                 //(guardada o no), está en la lista de propiedades
                
                UIAvisoPropiedadRepetida ui_aviso = new UIAvisoPropiedadRepetida(uiPropiedad,true);
                ui_aviso.setVisible(true);
            }
        }  
    
    
     /*
         MÉTODO QUE HABILITA Ó DESHABILITA EL BOTÓN "Chequear" AL SELECCIONAR
         UNA PROPIEDAD DE LA LISTA DE RPOPIEDADES, DEPENDIENDO SI DICHA 
         PROPIEDAD ES SINTÁCTICA Y SEMÁNTICAMENTE CORRECTA Ó NO.
     */ 
     public void actualizarLista() throws UnsupportedEncodingException, Exception{
            if(!uiModelo.getListaPropiedad().isSelectionEmpty()){//Si hay propiedad seleccionada
                String propiedadSeleccionada = quitarFormatoHTML((String)uiModelo.getListaPropiedad().getSelectedValue());
                String a =habilitar_deshabilitar_chequear(propiedadSeleccionada);                      
            }    
     }

     
     private String quitarFormatoHTML(String cadena){
         cadena = cadena.replaceAll("<html><font color=gray>", "");
         cadena = cadena.replaceAll("<html><font color=black>", "");
         cadena = cadena.replaceAll("</font></html>", "");
         return cadena;
     }
}
