package Interfaz.Eventos.EventosUIModelo;

import Interfaz.AuxiliarInterfaz.ConfiguracionTexto;
import Interfaz.InterfazGrafica.UIModelo;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.text.BadLocationException;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class KeyListenerUIModelo implements KeyListener {

/*
   Una instancia de 'KeyListenerUIModelo' está asociada a una única instancia de 
   UIModelo y EventosModelo (definidos en la sección de atributos)
*/ 
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private UIModelo uiModelo;
    private EventosModelo eventos_modelo;
    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public KeyListenerUIModelo(UIModelo uiModelo){
        this.uiModelo = uiModelo;
        this.eventos_modelo = new EventosModelo(uiModelo);
    }
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     IMPLEMENTACIÓN DE MÉTODOS DE LA INTERFAZ KeyListener PARA "UIModelo"
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    @Override
    public void keyTyped(KeyEvent ke) {    
    }

    
    /*
       MÉTODO QUE SE INVOCA AL PRESIONAR UNA TECLA.
    */
    @Override
    public void keyPressed(KeyEvent ke) {
       uiModelo.setLongitudTexto(uiModelo.getContenedorTextoModelo().getText().length());
    }
    
    
    /*
       MÉTODO QUE SE INVOCA LUEGO PRESIONAR UNA TECLA.
    */
    @Override
    public void keyReleased(KeyEvent ke) {
        try {
            eventos_modelo.actualizar_keyReleassed();
        } 
        catch (BadLocationException ex) {
            uiModelo.getContendorTextoMuestraResultado().setText("Error fatal: "+ex.getMessage());
            try {
                ConfiguracionTexto.darFormatoDeTexto(0,("Error fatal: "+ ex.getMessage()).length(),ConfiguracionTexto.getFormatoNegrita(), uiModelo.getContendorTextoMuestraResultado());
            } 
            catch (BadLocationException ex1) {
            }
        }
    }
 
}
