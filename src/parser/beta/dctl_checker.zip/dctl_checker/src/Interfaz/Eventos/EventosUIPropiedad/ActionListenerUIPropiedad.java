package Interfaz.Eventos.EventosUIPropiedad;

import Interfaz.InterfazGrafica.UIModelo;
import Interfaz.InterfazGrafica.UIPropiedadDCTL;
import Interfaz.AuxiliarInterfaz.ManipulacionArchivos;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ActionListenerUIPropiedad implements ActionListener{
   
/*
   Una instancia de 'WindowListenerUIModelo' está asociada a una única 
   instancia de UIModelo, UIPropiedadDCTL, Eventos_Propeidad,  
   ManipulacionArchivos y ActionEvent (definidos en la sección de atributos)
*/ 
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private UIPropiedadDCTL uiPropiedad;
    private UIModelo ui_modelo;
    private EventosPropiedad eventos_propiedad;
    private ManipulacionArchivos manipulacionArchivos;
    private ActionEvent actionEventModelo;

    
    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public ActionListenerUIPropiedad(UIPropiedadDCTL uiPropiedad, UIModelo ui_modelo,ActionEvent actionEventModelo){
        super();
        this.uiPropiedad = uiPropiedad;
        this.ui_modelo = ui_modelo;
        eventos_propiedad = new EventosPropiedad(ui_modelo,uiPropiedad);
        manipulacionArchivos = new ManipulacionArchivos(ui_modelo);
        this.actionEventModelo = actionEventModelo;
    }
    
    
    /*
     ---------------------------------------------------------------------- 
     ----------------------------------------------------------------------  
     IMPLEMENTACIÓN DEL MÉTODO DE LA INTERFAZ ActionListener PARA 
     "UIPropiedadDCTL"
     ---------------------------------------------------------------------- 
     ---------------------------------------------------------------------- 
    */
    @Override
    public void actionPerformed(ActionEvent ev) {
     
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN EL BOTÓN "Guardar".
        */
        if(ev.getSource() == uiPropiedad.getButtonGuardarPropiedad()){
            try {
                eventos_propiedad.guardarPropiedad(actionEventModelo);
            }
            catch (Exception ex) {
            }
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Copiar" DEL MENÚ "Editar". 
           EL TEXTO COPIADO QUEDA ALMACENADO EN LA PAPELERA.
        */
        if(ev.getSource() == uiPropiedad.getMenuItemCopiarPropiedad()){
            uiPropiedad.getContenedorTextoPropiedad().copy();
        }
        
        /*
   Una instancia de 'WindowListenerUIModelo' está asociada una única 
   instancia de UIModelo y Eventos_Modelo (definidos en la sección de atributos)
*/ 
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Cortar" DEL MENÚ "Editar". 
           EL TEXTO CORTADO QUEDA ALMACENADO EN LA PAPELERA.
        */
        if(ev.getSource() == uiPropiedad.getMenuItemCortarPropiedad()){
            uiPropiedad.getContenedorTextoPropiedad().cut();
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Pegar" DEL MENÚ "Editar". 
        */
        if(ev.getSource() == uiPropiedad.getMenuItemPegarPropiedad()){                 
            if(ui_modelo.getPropiedadAPegar().equals("")){// Si el texto a pegar no es una propiedad
                                                          //copiada desde la lista de propiedades
                
                /*
                   Se pega contenido de la papelera
                */
                uiPropiedad.getContenedorTextoPropiedad().paste();
            }
            else{// Si el texto a pegar es una propiedad copiada desde la lista de propiedades
                
                /*
                   Se pega la propiedad copiada ó cortada de la lista de propiedades
                */
                uiPropiedad.getContenedorTextoPropiedad().setText(ui_modelo.getPropiedadAPegar()); 
            }
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Copiar" DEL MENÚ QUE SE 
           DESPLIEGA AL HACER CLIC DERECHO EN EL CONTENEDOR DE TEXTO DONDE
           SE ESCRIBE UNA PROPIEDAD: 
           EL TEXTO COPIADO QUEDA ALMACENADO EN LA PAPELERA.
        */
        if(ev.getSource() == uiPropiedad.getMenuItemPopupCopiarPropiedad()){
            uiPropiedad.getContenedorTextoPropiedad().copy();
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Cortar" DEL MENÚ QUE SE 
           DESPLIEGA AL HACER CLIC DERECHO EN EL CONTENEDOR DE TEXTO DONDE
           SE ESCRIBE UNA PROPIEDAD: 
           EL TEXTO CORTADO QUEDA ALMACENADO EN LA PAPELERA.
        */
        if(ev.getSource() == uiPropiedad.getMenuItemPopupCortarPropiedad()){
            uiPropiedad.getContenedorTextoPropiedad().cut();
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN "Pegar" DEL MENÚ QUE SE 
           DESPLIEGA AL HACER CLIC DERECHO EN EL CONTENEDOR DE TEXTO DONDE
           SE ESCRIBE UNA PROPIEDAD: 
        */
        if(ev.getSource() == uiPropiedad.getMenuItemPopupPegarPropiedad()){
            if(ui_modelo.getPropiedadAPegar().equals("")){// Si el texto a pegar no es una propiedad
                                                          //copiada desde la lista de propiedades
                
                /*
                   Se pega contenido de la papelera
                */
                uiPropiedad.getContenedorTextoPropiedad().paste();
            }
            else{// Si el texto a pegar es una propiedad copiada desde la lista de propiedades
                
                /*
                   Se pega la propiedad copiada ó cortada de la lista de propiedades
                */
                uiPropiedad.getContenedorTextoPropiedad().setText(ui_modelo.getPropiedadAPegar()); 
            }  
        }
        
        
        /*
           MÉTODO QUE SE INVOCA AL HACER CLIC EN EL BOTÓN "Salir".
           SE ELIMINA LA VENTANA UIPropiedadDCTL.
        */
        if(ev.getSource() == uiPropiedad.getButtonSalir()){
            ui_modelo.setPropiedadAPegar("");
            uiPropiedad.dispose();
        }    
        
    }
    
  
   
  
}
