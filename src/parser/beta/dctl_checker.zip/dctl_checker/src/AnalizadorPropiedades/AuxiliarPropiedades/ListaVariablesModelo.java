package AnalizadorPropiedades.AuxiliarPropiedades;

import java.util.List;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class ListaVariablesModelo {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private static List variablesDeclaradas;//Almacena una lista
    
      
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    public static List getListaVariables(){
        return variablesDeclaradas;
    }
    
    
    public static void setListaVariables(List variablesDeclaradas){
        ListaVariablesModelo.variablesDeclaradas = variablesDeclaradas;
    }

}
