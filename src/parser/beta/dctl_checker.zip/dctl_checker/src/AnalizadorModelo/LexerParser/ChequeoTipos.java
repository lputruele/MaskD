package AnalizadorModelo.LexerParser;

/**
 *
 * @author Giuliodori Eugenia, Torello Elina
 */

/*
    Clase que realiza los chequeos de tipos de las operaciones de un modelo
*/
public class ChequeoTipos { 

   //int=0 y bool=1
    public static int getTipo(String tipo){
        int tipoOperando=-1;
        if(tipo.compareTo("INT")==0){
	    tipoOperando = 0;  
	}	
	if(tipo.compareTo("BOOL")==0){
	    tipoOperando = 1;  
	}
        return tipoOperando;
    }
    
    

    public static boolean esErrorDeTipo(String operador, int tipoOperando1, int tipoOperando2){
        boolean chequeoValido =true; 
 	if (operador.equals("->")){
	    chequeoValido=tipoOperando1==1;
	}
	if(operador.equals("=")){
	    chequeoValido=((tipoOperando1==0) && (tipoOperando2==0))||((tipoOperando1==1) && (tipoOperando2==1));
	}
	if(operador.equals("||")){
	    chequeoValido=(tipoOperando1==1)&&(tipoOperando2==1); 
	}
	if(operador.equals("&&")){
	    chequeoValido=(tipoOperando1==1)&&(tipoOperando2==1);
	}
	if(operador.equals("==")){
	    chequeoValido=((tipoOperando1==0) && (tipoOperando2==0))||((tipoOperando1==1) && (tipoOperando2==1));
	}
        if(operador.equals("+")){
	    chequeoValido=(tipoOperando1==0) && (tipoOperando2==0);
	}
        if(operador.equals("-")){
	    chequeoValido=((tipoOperando1==0) && (tipoOperando2==0))||((tipoOperando1==0) && (tipoOperando2==-1));
	}
	if(operador.equals("*")){
	    chequeoValido=(tipoOperando1==0) && (tipoOperando2==0);
	}
	if(operador.equals("/")){
	    chequeoValido=(tipoOperando1==0) && (tipoOperando2==0);
	}
	if(operador.equals("!")){
	    chequeoValido=tipoOperando1==1;
	}
	if(operador.equals(">")){
	    chequeoValido=(tipoOperando1==0) && (tipoOperando2==0);
	};
        if(operador.equals("<")){
	    chequeoValido=(tipoOperando1==0) && (tipoOperando2==0);
	}
        return !chequeoValido;
    }
}

