package AnalizadorModelo.LexerParser;

/**
 *
 * @author Giuliodori Eugenia, Torello Elina
 */

/**
 * Clase que contiene informacion adicional sobre los tokens con respecto a las clases de errores que pueden aparecer
 * 
 */
public class ErrorSintacticoSemantico{
    public enum Error{VBLENODEFINIDA,VBLEAMBIGUA,ERRORDETIPO,ERRORGRAMATICAL,ERRORASIGNACION};
    private Error tipoError;
    private String descripcion; 
    private int nroLinea;
    

    public ErrorSintacticoSemantico(){
        descripcion = new String("");
        tipoError=null;
        nroLinea=0;
    }
    
    
            
        
        
        public int getNroLinea(){
            return nroLinea;
        }
        
        public void setNroLinea(int nroLinea){
            this.nroLinea = nroLinea;
        }
    
    /**
    * Método que te devuelve el tipo de error
    * @return el tipo de error 
    */
    
    public String getDescripcion(){
        return descripcion;
    }
    
    public Error getTipo(){
        return tipoError;
    }
    
    public void setTipo(Error tipoError){
        this.tipoError=tipoError;
    }
    
    /**
    * Método que asocia un número a cada tipo de datos básico del lenguaje
    * @param tipoError que obtiene la informacion sobre el tipo de error que es
    */   
    public void setDescripcion(String descripcionError){
        this.descripcion=descripcionError;
    }
    
    
     /**
    * Método que te informa el tipo de error y el numero de linea en donde se produjo el error
    * @return un String que representa la informacion del tipo de error y el numero de linea en donde se produjo el error
    */
    
    public String toString(){  
        
        String info = this.descripcion + "\nNúmero de línea:  " + this.nroLinea;
        return info;    
    }
}
