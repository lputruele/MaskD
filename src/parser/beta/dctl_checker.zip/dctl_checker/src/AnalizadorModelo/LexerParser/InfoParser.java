package AnalizadorModelo.LexerParser;
import AnalizadorModelo.AuxiliarModelo.Valor;
import net.sf.javabdd.BDD;
/**
 *
 * @author Giuliodori Eugenia, Torello Elina
 */
public class InfoParser   {
	private String tipo;
	private Valor valor;
	private String nombreToken;
        private ErrorSintacticoSemantico error;
        private BDD bdd;
        

                
        public InfoParser(int nroLinea) {
            tipo="";
            valor=null; 
            nombreToken="";
            error=new ErrorSintacticoSemantico();
            bdd=null;
            
        }

	public String getTipo (){
		return tipo;
	}
        

	
	public Valor getValor (){
		return valor;
	}

	public void setTipo(String tipo){
			this.tipo=tipo;
	}
        

	public void setValor(Valor valor){
			this.valor=valor;
	}


        
	public String getNombre(){
			return nombreToken;
	}
	

	public void setNombre(String nombreToken){
			this.nombreToken=nombreToken;
	}

        
        public ErrorSintacticoSemantico getError(){
            return error;
        }
        

        public void setError(ErrorSintacticoSemantico error){
            this.error=error;
        }

        
        public BDD getBDD(){
            return bdd;
        }
        
        public void setBDD(BDD bdd){
            this.bdd=bdd;
        }

        
        public void set_tipo_nombre(String tipo,String nombre){
            this.setTipo(tipo);
            this.setNombre(nombre);

        }
        

}

