package AnalizadorModelo.AuxiliarModelo;


/**
 * @author Giuliodori Eugenia, Torello Elina
 */
public class Par {
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ------------------------------ATRIBUTOS------------------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    private Object primero;//Almacena primer elemento del par
    private Object segundo;//Almacena segundo elemento del par

    
    /*
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
        ------------------------------CONSTRUCTOR----------------------------- 
        ---------------------------------------------------------------------- 
        ---------------------------------------------------------------------- 
    */
    public Par(Object primero, Object segundo){
        this.primero=primero;
        this.segundo=segundo;
    }
    
    
    /* 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
       ----------------------get() Y set() DE ATRIBUTOS---------------------- 
       ---------------------------------------------------------------------- 
       ---------------------------------------------------------------------- 
    */
    
    
    public Object getPrimero(){
        return primero;
    }
    
    
    public Object getSegundo(){
        return segundo;
    }
    
    
    public void setPrimero(Object primero){
        this.primero=primero;
    }
    
    
    public void setSegundo(Object segundo){
        this.segundo=segundo;
    }
    
}
