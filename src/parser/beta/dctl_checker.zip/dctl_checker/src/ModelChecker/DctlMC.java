package ModelChecker;

import Formulas.FormulaElement;
import Formulas.SatVisitor;
import net.sf.javabdd.*;
import ModelChecker.BDDModel.*;

public class DctlMC {

public static boolean mc_algorithm(FormulaElement form, BDDModel m){
	
	BDD sat_form = Sat(form, m);
	try{
	if (sat_form.and(m.getIni()).satCount() > 0 )
		return true;
	else
	    return false;
	}
	catch(NullPointerException e){
		return false;
	}
}	

private static BDD Sat(FormulaElement f, BDDModel m){	

	SatVisitor s = new SatVisitor(m);
        f.accept(s); 
	return s.getSat();
}

}
