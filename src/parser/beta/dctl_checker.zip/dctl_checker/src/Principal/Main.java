
package Principal;

import Interfaz.InterfazGrafica.GUIPrincipal;

/**
 *
 * @author Giuliodori Eugenia, Torello Elina
 */
public class Main {
    
    public static void main (String args[]){

        /* ABRE LA VENTANA PRINCIPAL */
        GUIPrincipal ventanaPrincipal = new GUIPrincipal();
        //ventanaPrincipal.setExtendedState(JFrame.MAXIMIZED_BOTH);//para maximizar el frame
        ventanaPrincipal.setVisible(true);


    }
}
